#!/usr/bin/env python3
"""
NextcloudShare plugin for Dynaframe Pro.

Brings the pictures of Nextcloud folders into Dynaframe as an image source (it shows up as a source you
can switch on in Choose Playlist, like Immich or DeviantArt).

Everything is set up on the plugin's own page ("Open Nextcloud sources" on the Plugins page):
- any number of public share links (each with its own optional password),
- any number of folders of a Nextcloud account (user name + app password),
- each source can be tested, switched off or removed, and shows what was found.
The pictures of all active sources are downloaded into the plugin's cache folder (only new or changed
ones), pictures that disappeared are removed, and the cache is submitted to Dynaframe. If one source
cannot be read (wrong password, server offline) its pictures stay as they were and the others are
still updated.

The sources (with their passwords) are kept in data/sources.json inside the plugin folder, readable only
by the plugin's user. The page is served on 127.0.0.1 only and never shows a stored password again.
The Dynaframe action stream needs the "requests" package (requirements.txt); the plugin itself uses only
the standard library.
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass
_crash_log_path = os.path.join(_plugin_dir, "crash.log")


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(_crash_log_path, "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import base64
import hashlib
import json
import random
import re
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from dynaframe_plugin_base import create_plugin

plugin = create_plugin()

CACHE_DIR = Path(_plugin_dir) / "cache"
_shutdown_event = threading.Event()
_fetch_lock = threading.Lock()

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}
_DAV = "{DAV:}"


# ---------------------------------------------------------------- configuration (data/sources.json)

DATA_DIR = Path(_plugin_dir) / "data"
CONFIG_FILE = DATA_DIR / "sources.json"
_config_lock = threading.RLock()
DEFAULT_OPTIONS = {"Recursive": True, "MaxPictures": 300, "PickMode": "random", "MaxFileMB": 30,
                   "IncludeVideos": False, "RefreshMinutes": 60}


def _setting(name, default=""):
    """A value from the host's settings (only used to import an older configuration once)."""
    try:
        v = plugin.get_setting(name, default)
    except Exception:
        return default
    return default if v is None else v


def _legacy_config():
    """Older versions kept everything in the plugin settings; take it over once."""
    sources = []
    default_pw = str(_setting("SharePassword", ""))
    text = str(_setting("ShareLinks", "")) or str(_setting("ShareUrl", ""))
    for part in re.split(r"[;\n\r]+|\s+(?=https?://)", text):
        part = part.strip()
        if not part:
            continue
        url, sep, pw = part.partition("|")
        sources.append({"id": uuid.uuid4().hex[:8], "type": "share", "name": "", "enabled": True,
                        "url": url.strip(), "password": pw.strip() if sep else default_pw})
    server, user = str(_setting("ServerUrl", "")).strip(), str(_setting("Username", "")).strip()
    if server and user:
        sources.append({"id": uuid.uuid4().hex[:8], "type": "account", "name": "", "enabled": True,
                        "server": server, "user": user, "password": str(_setting("Password", "")),
                        "folders": str(_setting("FolderPath", "/")) or "/"})
    options = dict(DEFAULT_OPTIONS)
    for k, kind in (("Recursive", bool), ("IncludeVideos", bool), ("MaxPictures", int), ("MaxFileMB", int),
                    ("RefreshMinutes", int), ("PickMode", str)):
        raw = _setting(k, None)
        if raw in (None, ""):
            continue
        try:
            options[k] = (str(raw).lower() in ("1", "true", "yes", "on")) if kind is bool else kind(float(raw) if kind is int else raw)
        except (TypeError, ValueError):
            pass
    return {"sources": sources, "options": options}


def load_config():
    with _config_lock:
        try:
            cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(cfg, dict) and isinstance(cfg.get("sources"), list):
                cfg["options"] = {**DEFAULT_OPTIONS, **(cfg.get("options") or {})}
                return cfg
        except (OSError, ValueError):
            pass
        cfg = _legacy_config()
        save_config(cfg)
        return cfg


def save_config(cfg):
    with _config_lock:
        DATA_DIR.mkdir(exist_ok=True)
        tmp = CONFIG_FILE.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # passwords: owner only
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_FILE)


def _opt(name):
    return load_config()["options"].get(name, DEFAULT_OPTIONS[name])


def _opt_number(name, minimum, maximum=None):
    try:
        v = max(minimum, float(_opt(name)))
    except (TypeError, ValueError):
        v = max(minimum, float(DEFAULT_OPTIONS[name]))
    return min(maximum, v) if maximum is not None else v


class Access:
    """One WebDAV folder: where it is and how to log in."""

    def __init__(self, source_id, kind, label, base, root, user, password, link):
        self.source_id, self.kind, self.label, self.password, self.user, self.link = source_id, kind, label, password, user, link
        parts = urllib.parse.urlparse(base)
        self.origin = f"{parts.scheme}://{parts.netloc}"
        # Nextcloud may live in a sub folder (https://host/nextcloud): the server's hrefs include it.
        self.root = parts.path.rstrip("/") + root
        self.key = hashlib.sha1((kind + base + root + user).encode("utf-8")).hexdigest()[:6]

    def header(self):
        raw = f"{self.user}:{self.password}".encode("utf-8")
        return {"Authorization": "Basic " + base64.b64encode(raw).decode("ascii")}


_SHARE_RE = re.compile(r"^(https?://.+?)/(?:index\.php/)?s/([A-Za-z0-9_-]+)", re.I)


def source_title(src):
    if src.get("name"):
        return src["name"]
    if src.get("type") == "account":
        return f"{src.get('user', '')} @ {urllib.parse.urlparse(str(src.get('server', ''))).netloc or src.get('server', '')}"
    m = _SHARE_RE.match(str(src.get("url", "")))
    return f"{urllib.parse.urlparse(m.group(1)).netloc} / ...{m.group(2)[-4:]}" if m else str(src.get("url", ""))[:40]


def accesses_for(src):
    """The WebDAV folders one configured source stands for. Raises ValueError for a bad entry."""
    label = source_title(src)
    if src.get("type") == "account":
        server = str(src.get("server", "")).strip().rstrip("/")
        user = str(src.get("user", "")).strip()
        if not server or not user:
            raise ValueError("Server address and user name are both needed")
        if not re.match(r"^https?://", server, re.I):
            server = "https://" + server
        out = []
        for folder in [f for f in re.split(r"[;\n\r]+", str(src.get("folders", "/")) or "/")] or ["/"]:
            folder = folder.strip().strip("/")
            root = f"/remote.php/dav/files/{urllib.parse.quote(user)}/" + (urllib.parse.quote(folder, safe="/") + "/" if folder else "")
            out.append(Access(src["id"], "account", f"{label} /{folder}", server, root, user, str(src.get("password", "")), server))
        return out
    url = str(src.get("url", "")).strip()
    m = _SHARE_RE.match(url)
    if not m:
        raise ValueError("This does not look like a share link (https://your-cloud/s/AbCdEf123)")
    base, token = m.group(1), m.group(2)
    return [Access(src["id"], "share", label, base, "/public.php/webdav/", token, str(src.get("password", "")), url)]


# ---------------------------------------------------------------- one playlist per source (Engine REST)

class EngineError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def _engine_url():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def _engine_headers():
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    cred = str(getattr(plugin, "plugin_credential", "") or "")
    gen = str(getattr(plugin, "process_generation", "") or "")
    if cred:
        h["X-Dfr-Plugin-Credential"] = cred
    if gen:
        h["X-Dfr-Plugin-Generation"] = gen
    return h


def engine_call(method, path, payload=None, timeout=20):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(_engine_url() + path, data=data, method=method, headers=_engine_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        raise EngineError(f"{method} {path} returned HTTP {exc.code} {body}", status=exc.code) from exc
    except (urllib.error.URLError, OSError) as exc:
        raise EngineError(f"{method} {path} failed: {exc}") from exc
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except ValueError:
        return None


def _set_source(source_id, **kv):
    with _config_lock:
        cfg = load_config()
        for s in cfg["sources"]:
            if s["id"] == source_id:
                s.update(kv)
        save_config(cfg)


def playlist_name(src):
    return "Nextcloud: " + source_title(src)


def _find_media_id(path):
    q = urllib.parse.urlencode({"query": Path(path).stem})
    found = engine_call("GET", f"/media/database/search?{q}")
    if isinstance(found, dict):
        found = found.get("items") or found.get("results") or []
    for row in found or []:
        if isinstance(row, dict) and row.get("filePath") == str(path):
            for k in ("id", "mediaFileId"):
                if row.get(k) is not None:
                    return row[k]
    return None


def _media_ids(paths):
    """Engine ids of the submitted files. A new file may take a moment to be registered."""
    ids, missing = {}, list(paths)
    for attempt in range(6):
        still = []
        for pth in missing:
            try:
                mid = _find_media_id(pth)
            except EngineError as exc:
                plugin.log(f"Media lookup: {exc}", level="warning")
                mid = None
            if mid is None:
                still.append(pth)
            else:
                ids[pth] = mid
        missing = still
        if not missing or _shutdown_event.is_set():
            break
        _shutdown_event.wait(3)
    if missing:
        plugin.log(f"{len(missing)} pictures are not registered in Dynaframe yet; they join the playlist at the next update.",
                   level="warning")
    return [ids[pth] for pth in paths if pth in ids]


def _playlist_items(pid):
    items = engine_call("GET", f"/playlists/{pid}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return items


def _playlist_id_of(obj):
    return (obj or {}).get("id") or ((obj or {}).get("playlist") or {}).get("id")


def _ensure_playlist(src, create):
    """The playlist of a source (made if it does not exist and create is True). Returns its id or None."""
    pid = src.get("playlistId")
    if pid:
        try:
            info = engine_call("GET", f"/playlists/{pid}") or {}
            want = playlist_name(src)
            if info.get("name") and info.get("name") != want:
                engine_call("PUT", f"/playlists/{pid}", {"name": want})
            return pid
        except EngineError as exc:
            if exc.status != 404:
                raise
    if not create:
        return None
    created = engine_call("POST", "/playlists", {"name": playlist_name(src),
                                                 "description": "Pictures of a Nextcloud source (kept up to date by the Nextcloud Share plugin)"})
    pid = _playlist_id_of(created)
    if not pid:
        raise EngineError("Dynaframe did not make the playlist")
    _set_source(src["id"], playlistId=pid)
    plugin.log(f"Made the playlist \"{playlist_name(src)}\".")
    return pid


def _fill_playlist(src, pid, media_ids):
    items = _playlist_items(pid)
    have = [it.get("mediaFileId", it.get("mediaId")) for it in items if isinstance(it, dict)]
    if len(have) == len(items) and None not in have and sorted(map(str, have)) == sorted(map(str, media_ids)):
        return pid                                            # nothing changed
    try:
        for it in items:
            engine_call("DELETE", f"/playlists/{pid}/items/{it['id']}")
    except (EngineError, KeyError):
        engine_call("DELETE", f"/playlists/{pid}")            # remake it
        _set_source(src["id"], playlistId=None)
        pid = _ensure_playlist({**src, "playlistId": None}, True)
    shape = None
    for mid in media_ids:
        bodies = [shape] if shape else [{"mediaFileId": "{}"}, {"contentType": "media", "mediaFileId": "{}"}]
        for body in bodies:
            payload = {k: (mid if v == "{}" else v) for k, v in body.items()}
            try:
                engine_call("POST", f"/playlists/{pid}/items", payload)
                shape = body
                break
            except EngineError as exc:
                last = exc
        else:
            raise last
    return pid


def update_playlists(sources, by_source, failed_ids):
    """One playlist per source, holding exactly that source's pictures."""
    current = {s["id"]: s for s in load_config()["sources"]}   # a source removed meanwhile gets no playlist
    for src in sources:
        src = current.get(src["id"])
        if src is None:
            continue
        if src["id"] in failed_ids or _shutdown_event.is_set():
            continue                                          # unreadable now: leave its playlist as it is
        active = src.get("enabled", True)
        paths = by_source.get(src["id"], []) if active else []
        try:
            pid = _ensure_playlist(src, create=bool(paths) or active)
            if pid is None:
                continue
            pid = _fill_playlist(src, pid, _media_ids(paths))
            if src["id"] not in {s["id"] for s in load_config()["sources"]}:
                remove_playlist({"playlistId": pid})          # the source was deleted while we were working
        except EngineError as exc:
            plugin.log(f"Playlist of {source_title(src)}: {exc}", level="warning")


def remove_playlist(src):
    pid = src.get("playlistId")
    if pid:
        try:
            engine_call("DELETE", f"/playlists/{pid}")
        except EngineError as exc:
            if exc.status != 404:
                plugin.log(f"Could not remove the playlist: {exc}", level="warning")


# ---------------------------------------------------------------- WebDAV

def _request(acc, method, href, headers=None, body=None, timeout=60):
    h = {"User-Agent": "Dynaframe-NextcloudShare/0.1", **acc.header(), **(headers or {})}
    req = urllib.request.Request(acc.origin + href, data=body, method=method, headers=h)
    return urllib.request.urlopen(req, timeout=timeout)


_PROPFIND = (b'<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getetag/>'
             b'<d:getcontentlength/><d:getlastmodified/><d:getcontenttype/></d:prop></d:propfind>')


def _propfind(acc, href):
    try:
        with _request(acc, "PROPFIND", href, {"Depth": "1", "Content-Type": "application/xml"}, _PROPFIND) as r:
            data = r.read()
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise RuntimeError("Login refused (401): check the share password / user name / password") from exc
        if exc.code == 404:
            raise RuntimeError("Folder not found (404): check the link or FolderPath") from exc
        raise RuntimeError(f"Nextcloud answered HTTP {exc.code}") from exc
    entries = []
    for resp in ET.fromstring(data).iter(_DAV + "response"):
        h = urllib.parse.unquote(resp.findtext(_DAV + "href") or "")
        props = {}
        for ps in resp.iter(_DAV + "propstat"):
            if " 200 " in (ps.findtext(_DAV + "status") or ""):
                p = ps.find(_DAV + "prop")
                if p is not None:
                    props = p
        if not len(props):
            continue
        is_dir = props.find(_DAV + "resourcetype") is not None and props.find(_DAV + "resourcetype").find(_DAV + "collection") is not None
        entries.append({
            "href": h, "dir": is_dir,
            "etag": (props.findtext(_DAV + "getetag") or "").strip('"'),
            "size": int(props.findtext(_DAV + "getcontentlength") or 0),
            "modified": props.findtext(_DAV + "getlastmodified") or "",
        })
    return entries


def list_pictures(acc):
    """All picture files below the root as dicts (path = path relative to the root)."""
    root_path = urllib.parse.unquote(acc.root)
    recursive = bool(_opt("Recursive"))
    include_video = bool(_opt("IncludeVideos"))
    exts = IMAGE_EXT | (VIDEO_EXT if include_video else set())
    max_bytes = int(_opt_number("MaxFileMB", 1, 500) * 1024 * 1024)
    out, queue, seen = [], [acc.root], set()
    while queue and not _shutdown_event.is_set():
        href = queue.pop(0)
        if href in seen:
            continue
        seen.add(href)
        for e in _propfind(acc, href):
            full = e["href"]
            if full.rstrip("/") == urllib.parse.unquote(href).rstrip("/"):
                continue
            rel = full[len(root_path):] if full.startswith(root_path) else full.lstrip("/")
            name = rel.rstrip("/").split("/")[-1]
            if not name or name.startswith("."):
                continue
            if e["dir"]:
                if recursive and len(seen) < 500:
                    queue.append(urllib.parse.quote(full))
                continue
            if Path(name).suffix.lower() in exts and 0 < e["size"] <= max_bytes:
                e["path"], e["name"] = rel, name
                out.append(e)
    return out


def _download(acc, entry, dest):
    href = acc.root + urllib.parse.quote(entry["path"])
    tmp = dest.with_suffix(dest.suffix + ".part")
    with _request(acc, "GET", href, timeout=120) as r, open(tmp, "wb") as f:
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk)
    os.replace(tmp, dest)


# ---------------------------------------------------------------- sync

STATUS = {}                       # source id -> what the last check found
RUN = {"running": False, "last": "", "message": "Not run yet", "pictures": 0}


def _local_name(acc, entry):
    return f"nc_{acc.key}_" + hashlib.sha1(entry["path"].encode("utf-8")).hexdigest()[:14] + Path(entry["name"]).suffix.lower()


def _modified_ts(entry):
    try:
        return parsedate_to_datetime(entry["modified"]).timestamp()
    except Exception:
        return 0.0


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def sync():
    """Mirror all active sources into the cache and submit it. Returns the number of pictures."""
    cfg = load_config()
    active = [s for s in cfg["sources"] if s.get("enabled", True)]
    for s in cfg["sources"]:
        if not s.get("enabled", True):
            STATUS[s["id"]] = {"ok": None, "pictures": 0, "message": "Switched off", "checked": _now()}
    if not active:
        # Nothing (left) to show: empty the cache and the catalog, so no old picture stays on the frame.
        _clear_cache()
        plugin.submit_media([], replace_catalog=True)
        plugin.log("Nextcloud: no active source, the pictures were removed from the frame")
        try:
            update_playlists(cfg["sources"], {}, set())
        except Exception as exc:  # noqa: BLE001
            plugin.log(f"Playlists could not be updated: {exc}", level="warning")
        return 0
    entries, failed_accesses = [], []
    for src in active:
        if _shutdown_event.is_set():
            return 0
        found_total, errors = 0, []
        try:
            accesses = accesses_for(src)
        except ValueError as exc:
            STATUS[src["id"]] = {"ok": False, "pictures": 0, "message": str(exc), "checked": _now()}
            continue
        for acc in accesses:
            try:
                found = list_pictures(acc)
            except Exception as exc:  # noqa: BLE001
                failed_accesses.append(acc)
                errors.append(str(exc))
                plugin.log(f"Nextcloud {acc.label}: {exc}", level="warning")
                continue
            for e in found:
                e["acc"] = acc
            entries.extend(found)
            found_total += len(found)
        STATUS[src["id"]] = {"ok": not errors, "pictures": found_total,
                             "message": (errors[0] if errors else (f"{found_total} pictures found" if found_total else "No pictures found")),
                             "checked": _now()}
    if failed_accesses and all(STATUS[s["id"]]["ok"] is False for s in active if s["id"] in STATUS):
        raise RuntimeError("None of the sources could be read (see the page for details)")
    limit = int(_opt_number("MaxPictures", 1, 5000))
    grouped = {}
    for e in entries:
        grouped.setdefault(e["acc"].source_id, []).append(e)
    entries = []
    for lst in grouped.values():          # the limit counts per source: every source has its own playlist
        if len(lst) > limit:
            if str(_opt("PickMode")) == "newest":
                lst.sort(key=_modified_ts, reverse=True)
            else:
                random.shuffle(lst)
            lst = lst[:limit]
        entries.extend(lst)
    CACHE_DIR.mkdir(exist_ok=True)
    keep, paths, failed = set(), [], 0
    by_source = {}
    for e in entries:
        if _shutdown_event.is_set() or not plugin.is_running():
            break
        acc = e["acc"]
        dest = CACHE_DIR / _local_name(acc, e)
        side = dest.with_suffix(dest.suffix + ".json")
        keep.update({dest.name, side.name})
        old = {}
        try:
            old = json.loads(side.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        if not (dest.exists() and old.get("etag") == e["etag"] and old.get("size") == e["size"]):
            try:
                _download(acc, e, dest)
            except Exception as exc:  # noqa: BLE001
                failed += 1
                plugin.log(f"Could not download {e['path']}: {exc}", level="warning")
                continue
            folder = e["path"].rsplit("/", 1)[0] if "/" in e["path"] else ""
            side.write_text(json.dumps({
                "title": Path(e["name"]).stem, "subject": folder, "provider": "Nextcloud",
                "original_url": acc.link, "etag": e["etag"], "size": e["size"],
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        paths.append(str(dest))
        by_source.setdefault(acc.source_id, []).append(str(dest))
    if failed == len(entries) and entries:
        raise RuntimeError("No picture could be downloaded")
    if not _shutdown_event.is_set():
        # Pictures of a folder that could not be read this time stay as they are; so do those of
        # sources that were removed from the active list only after a successful run.
        protected = tuple(f"nc_{a.key}_" for a in failed_accesses)
        for f in CACHE_DIR.glob("nc_*"):
            if f.name in keep or f.name.endswith(".part"):
                continue
            if protected and f.name.startswith(protected):
                if not f.name.endswith(".json"):
                    paths.append(str(f))
                continue
            try:
                f.unlink()
            except OSError:
                pass
    if paths or not failed_accesses:
        # An empty list is deliberate when every source could be read and has nothing (any more).
        plugin.submit_media(paths, replace_catalog=True)
    if not _shutdown_event.is_set():
        try:
            update_playlists(cfg["sources"], by_source, {a.source_id for a in failed_accesses})
        except Exception as exc:  # noqa: BLE001
            plugin.log(f"Playlists could not be updated: {exc}", level="warning")
    plugin.log(f"Nextcloud: {len(paths)} pictures ready from {len(active) - len({a.source_id for a in failed_accesses})} of {len(active)} sources"
               + (f", {failed} failed" if failed else ""))
    return len(paths)


_rerun = threading.Event()


def _clear_cache():
    for f in CACHE_DIR.glob("nc_*"):
        try:
            f.unlink()
        except OSError:
            pass


def refresh(_action=None):
    if not _fetch_lock.acquire(blocking=False):
        _rerun.set()          # run once more as soon as the current update is done
        plugin.log("A Nextcloud update is already running; will run again afterwards")
        return
    _rerun.clear()
    RUN.update(running=True, message="Updating...")
    plugin.content_refresh_started("Reading the Nextcloud folders...")
    try:
        count = sync()
    except Exception as exc:  # noqa: BLE001
        RUN.update(message=f"Update failed: {exc}", last=_now())
        plugin.content_refresh_failed(f"Nextcloud update failed: {exc}")
        plugin.log(f"Nextcloud update failed: {exc}", level="error")
    else:
        RUN.update(message=(f"{count} pictures on the frame" if count else "No pictures on the frame (add a share link on this page)"),
                   pictures=count, last=_now())
        plugin.content_refresh_completed(count, "The Nextcloud pictures are up to date.")
    finally:
        RUN["running"] = False
        _fetch_lock.release()
        if _rerun.is_set():
            _rerun.clear()
            threading.Thread(target=refresh, daemon=True).start()


def test_source(src):
    """Try one source (saved or still a draft). Returns a dict for the page."""
    try:
        accesses = accesses_for(src)
    except ValueError as exc:
        return {"success": False, "message": str(exc)}
    total, folders, notes = 0, set(), []
    for acc in accesses:
        try:
            entries = list_pictures(acc)
        except Exception as exc:  # noqa: BLE001
            return {"success": False, "message": f"{acc.label}: {exc}"}
        total += len(entries)
        folders.update(e["path"].rsplit("/", 1)[0] for e in entries if "/" in e["path"])
    msg = f"Works: {total} pictures found" + (f" in {len(folders)} subfolders" if folders else "")
    return {"success": True, "pictures": total, "message": msg}


def test_connection(_action=None):
    for src in load_config()["sources"]:
        r = test_source(src)
        plugin.log(f"Nextcloud test ({source_title(src)}): {r['message']}", level="info" if r["success"] else "error")


# ---------------------------------------------------------------- the plugin's own page

STUDIO_DIR = Path(_plugin_dir) / "studio"
STUDIO_FILES = {"/studio.css": ("studio.css", "text/css; charset=utf-8"),
                "/studio.js": ("studio.js", "application/javascript; charset=utf-8")}
studio_server = None


def public_state():
    cfg = load_config()
    items = []
    for s in cfg["sources"]:
        st = STATUS.get(s["id"], {"ok": None, "pictures": 0, "message": "Not checked yet", "checked": ""})
        item = {"id": s["id"], "type": s.get("type", "share"), "name": s.get("name", ""), "title": source_title(s),
                "enabled": s.get("enabled", True), "hasPassword": bool(s.get("password")), "status": st,
                "playlist": playlist_name(s)}
        if item["type"] == "account":
            item.update(server=s.get("server", ""), user=s.get("user", ""), folders=s.get("folders", "/"))
        else:
            item["url"] = s.get("url", "")
        items.append(item)
    return {"sources": items, "options": cfg["options"], "run": dict(RUN), "plugin": "Nextcloud Share"}


def _clean_source(body, existing=None):
    """A source dict from the page's form. A blank password keeps the stored one."""
    typ = "account" if body.get("type") == "account" else "share"
    src = {"id": (existing or {}).get("id") or uuid.uuid4().hex[:8], "type": typ,
           "playlistId": (existing or {}).get("playlistId"),
           "name": str(body.get("name", "")).strip()[:60],
           "enabled": bool(body.get("enabled", (existing or {}).get("enabled", True)))}
    pw = body.get("password")
    src["password"] = (existing or {}).get("password", "") if pw in (None, "") else str(pw)
    if body.get("clearPassword"):
        src["password"] = ""
    if typ == "account":
        src.update(server=str(body.get("server", "")).strip(), user=str(body.get("user", "")).strip(),
                   folders=str(body.get("folders", "/")).strip() or "/")
    else:
        src["url"] = str(body.get("url", "")).strip()
    accesses_for(src)          # raises ValueError if it cannot work at all
    return src


class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_a):
        pass

    def _send(self, status, body, ctype):
        data = body if isinstance(body, bytes) else str(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj), "application/json; charset=utf-8")

    def do_GET(self):
        route = urllib.parse.urlparse(self.path).path
        try:
            if route in ("/", "/index.html"):
                self._send(200, (STUDIO_DIR / "index.html").read_bytes(), "text/html; charset=utf-8")
            elif route in STUDIO_FILES:
                name, ctype = STUDIO_FILES[route]
                self._send(200, (STUDIO_DIR / name).read_bytes(), ctype)
            elif route == "/api/state":
                self._json(public_state())
            else:
                self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:  # noqa: BLE001
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length > 0 else b""      # always drain (keep-alive)
        route = urllib.parse.urlparse(self.path).path
        # Another web page cannot send JSON to us without a CORS preflight, which is never granted.
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            self._json({"success": False, "error": "JSON only"}, 415)
            return
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except ValueError:
            body = {}
        try:
            self._json(self._route(route, body))
        except ValueError as exc:
            self._json({"success": False, "error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            plugin.log(f"Page request {route} failed: {exc}", level="warning")
            self._json({"success": False, "error": str(exc)}, 500)

    def _route(self, route, body):
        cfg = load_config()
        by_id = {s["id"]: s for s in cfg["sources"]}
        if route == "/api/add":
            added = 0
            if body.get("type") == "account":
                cfg["sources"].append(_clean_source(body))
                added = 1
            else:
                rows = []
                if isinstance(body.get("links"), list):
                    for r in body["links"]:
                        if isinstance(r, dict) and str(r.get("url", "")).strip():
                            rows.append((str(r["url"]).strip(), str(r.get("password", "")), str(r.get("name", ""))))
                else:                      # older form: one link per line, optional link|password
                    for line in re.split(r"[\n\r;]+|\s+(?=https?://)", str(body.get("urls", ""))):
                        url, sep, pw = line.strip().partition("|")
                        if url:
                            rows.append((url, pw.strip() if sep else body.get("password", ""), ""))
                for url, pw, name in rows:
                    if any(s.get("url", "").strip().rstrip("/") == url.rstrip("/") for s in cfg["sources"]):
                        continue          # already there
                    cfg["sources"].append(_clean_source({"type": "share", "url": url, "password": pw, "name": name}))
                    added += 1
                if not added:
                    raise ValueError("Enter at least one new share link (it may already be in the list)")
            save_config(cfg)
            threading.Thread(target=refresh, daemon=True).start()
            return {"success": True, "message": f"{added} source(s) added. Reading the folders now."}
        if route == "/api/save":
            src = by_id.get(body.get("id"))
            if not src:
                raise ValueError("Unknown source")
            new = _clean_source(body, src)
            cfg["sources"] = [new if s["id"] == src["id"] else s for s in cfg["sources"]]
            save_config(cfg)
            threading.Thread(target=refresh, daemon=True).start()
            return {"success": True, "message": "Saved. Reading the folders now."}
        if route == "/api/delete":
            for s in cfg["sources"]:
                if s["id"] == body.get("id"):
                    remove_playlist(s)
            cfg["sources"] = [s for s in cfg["sources"] if s["id"] != body.get("id")]
            STATUS.pop(body.get("id"), None)
            save_config(cfg)
            threading.Thread(target=refresh, daemon=True).start()
            return {"success": True, "message": "Removed. The frame is updated now."}
        if route == "/api/toggle":
            src = by_id.get(body.get("id"))
            if not src:
                raise ValueError("Unknown source")
            src["enabled"] = bool(body.get("enabled"))
            save_config(cfg)
            threading.Thread(target=refresh, daemon=True).start()
            return {"success": True}
        if route == "/api/test":
            existing = by_id.get(body.get("id"))
            return test_source(_clean_source(body, existing))
        if route == "/api/options":
            opts = dict(cfg["options"])
            o = body.get("options") or {}
            opts["Recursive"] = bool(o.get("Recursive", opts["Recursive"]))
            opts["IncludeVideos"] = bool(o.get("IncludeVideos", opts["IncludeVideos"]))
            opts["PickMode"] = "newest" if o.get("PickMode") == "newest" else "random"
            for k, lo, hi in (("MaxPictures", 1, 5000), ("MaxFileMB", 1, 500), ("RefreshMinutes", 5, 1440)):
                try:
                    opts[k] = int(min(hi, max(lo, float(o.get(k, opts[k])))))
                except (TypeError, ValueError):
                    pass
            cfg["options"] = opts
            save_config(cfg)
            return {"success": True, "message": "Saved. Applied at the next update."}
        if route == "/api/refresh":
            if RUN["running"]:
                return {"success": True, "message": "An update is already running."}
            threading.Thread(target=refresh, daemon=True).start()
            return {"success": True, "message": "Updating now."}
        return {"success": False, "error": "Unknown action"}


def start_studio():
    """Serve the plugin's page on loopback and tell the host where it is (port 0 = any free port)."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name="NextcloudShare-page", daemon=True).start()
    plugin.register_advanced_settings_page(f"http://127.0.0.1:{port}/")
    plugin.log(f"Plugin page listening on 127.0.0.1:{port}")


def stop_studio():
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass


def main():
    plugin.on_action("refresh", lambda _a=None: threading.Thread(target=refresh, daemon=True).start())
    plugin.on_action("test-connection", lambda _a=None: threading.Thread(target=test_connection, daemon=True).start())
    plugin.connect_sse()
    plugin.ready()
    plugin.log("Nextcloud Share 0.4.0 started")
    load_config()            # imports an older configuration once
    try:
        start_studio()
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Could not start the plugin page: {exc}", level="warning")
    # Give the action stream a moment to connect before any long work starts; the work itself
    # runs in a background thread so this thread (and the buttons) never wait for it.
    _shutdown_event.wait(3)
    try:
        while plugin.is_running() and not _shutdown_event.is_set():
            threading.Thread(target=refresh, daemon=True).start()
            _shutdown_event.wait(_opt_number("RefreshMinutes", 5, 1440) * 60)
    finally:
        _shutdown_event.set()
        stop_studio()


if __name__ == "__main__":
    main()
