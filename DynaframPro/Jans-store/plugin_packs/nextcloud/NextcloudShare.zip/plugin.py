#!/usr/bin/env python3
"""
NextcloudShare plugin for Dynaframe Pro.

Brings the pictures of a Nextcloud folder into Dynaframe as an image source (it shows up as a source
you can switch on in Choose Playlist, like Immich or DeviantArt).

Two ways to reach the folder (setting AccessMode):
- share   : a public share link, e.g. https://cloud.example.org/s/AbCdEf123 (SharePassword if the link
            is password protected). Nothing else is needed.
- account : a Nextcloud account (Username + Password, ideally an app password) and a FolderPath.

The pictures are downloaded into the plugin's cache folder (only new or changed ones), pictures that
disappeared from the folder are removed, and the cache is submitted to Dynaframe. Only the Python
standard library is used.
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass
_crash_log_path = os.path.join(_plugin_dir, "crash.log")


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(_crash_log_path, "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import base64
import hashlib
import json
import random
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from dynaframe_plugin_base import create_plugin

plugin = create_plugin()

CACHE_DIR = Path(_plugin_dir) / "cache"
_shutdown_event = threading.Event()
_fetch_lock = threading.Lock()

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}
_DAV = "{DAV:}"


# ---------------------------------------------------------------- settings

def _setting(name, default=""):
    try:
        v = plugin.get_setting(name, default)
    except Exception:
        return default
    return default if v is None else v


def _bool(name, default):
    return str(_setting(name, default)).strip().lower() in ("1", "true", "yes", "on")


def _number(name, default, minimum, maximum=None):
    try:
        v = float(_setting(name, default))
    except (TypeError, ValueError):
        v = float(default)
    v = max(minimum, v)
    return min(maximum, v) if maximum is not None else v


class Access:
    """Where the WebDAV folder is and how to log in."""

    def __init__(self):
        mode = str(_setting("AccessMode", "share")).strip().lower()
        self.mode = mode
        if mode == "account":
            base = str(_setting("ServerUrl", "")).strip().rstrip("/")
            if base and not re.match(r"^https?://", base, re.I):
                base = "https://" + base
            user = str(_setting("Username", "")).strip()
            if not base or not user:
                raise RuntimeError("Account mode needs ServerUrl and Username")
            folder = str(_setting("FolderPath", "/")).strip().strip("/")
            self.base = base
            self.root = f"/remote.php/dav/files/{urllib.parse.quote(user)}/" + (urllib.parse.quote(folder) + "/" if folder else "")
            self.user, self.password = user, str(_setting("Password", ""))
            self.link = base
        else:
            url = str(_setting("ShareUrl", "")).strip()
            m = re.match(r"^(https?://.+?)/(?:index\.php/)?s/([A-Za-z0-9_-]+)", url, re.I)
            if not m:
                raise RuntimeError("ShareUrl must look like https://your-cloud/s/AbCdEf123")
            self.base, token = m.group(1), m.group(2)
            self.root = "/public.php/webdav/"
            self.user, self.password = token, str(_setting("SharePassword", ""))
            self.link = url

        # Nextcloud may live in a sub folder (https://host/nextcloud): the server's hrefs include it.
        parts = urllib.parse.urlparse(self.base)
        self.origin = f"{parts.scheme}://{parts.netloc}"
        self.root = parts.path.rstrip("/") + self.root

    def header(self):
        raw = f"{self.user}:{self.password}".encode("utf-8")
        return {"Authorization": "Basic " + base64.b64encode(raw).decode("ascii")}


# ---------------------------------------------------------------- WebDAV

def _request(acc, method, href, headers=None, body=None, timeout=60):
    h = {"User-Agent": "Dynaframe-NextcloudShare/0.1", **acc.header(), **(headers or {})}
    req = urllib.request.Request(acc.origin + href, data=body, method=method, headers=h)
    return urllib.request.urlopen(req, timeout=timeout)


_PROPFIND = (b'<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getetag/>'
             b'<d:getcontentlength/><d:getlastmodified/><d:getcontenttype/></d:prop></d:propfind>')


def _propfind(acc, href):
    try:
        with _request(acc, "PROPFIND", href, {"Depth": "1", "Content-Type": "application/xml"}, _PROPFIND) as r:
            data = r.read()
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise RuntimeError("Login refused (401): check the share password / user name / password") from exc
        if exc.code == 404:
            raise RuntimeError("Folder not found (404): check the link or FolderPath") from exc
        raise RuntimeError(f"Nextcloud answered HTTP {exc.code}") from exc
    entries = []
    for resp in ET.fromstring(data).iter(_DAV + "response"):
        h = urllib.parse.unquote(resp.findtext(_DAV + "href") or "")
        props = {}
        for ps in resp.iter(_DAV + "propstat"):
            if " 200 " in (ps.findtext(_DAV + "status") or ""):
                p = ps.find(_DAV + "prop")
                if p is not None:
                    props = p
        if not len(props):
            continue
        is_dir = props.find(_DAV + "resourcetype") is not None and props.find(_DAV + "resourcetype").find(_DAV + "collection") is not None
        entries.append({
            "href": h, "dir": is_dir,
            "etag": (props.findtext(_DAV + "getetag") or "").strip('"'),
            "size": int(props.findtext(_DAV + "getcontentlength") or 0),
            "modified": props.findtext(_DAV + "getlastmodified") or "",
        })
    return entries


def list_pictures(acc):
    """All picture files below the root as dicts (path = path relative to the root)."""
    root_path = urllib.parse.unquote(acc.root)
    recursive = _bool("Recursive", True)
    include_video = _bool("IncludeVideos", False)
    exts = IMAGE_EXT | (VIDEO_EXT if include_video else set())
    max_bytes = int(_number("MaxFileMB", 30, 1, 500) * 1024 * 1024)
    out, queue, seen = [], [acc.root], set()
    while queue and not _shutdown_event.is_set():
        href = queue.pop(0)
        if href in seen:
            continue
        seen.add(href)
        for e in _propfind(acc, href):
            full = e["href"]
            if full.rstrip("/") == urllib.parse.unquote(href).rstrip("/"):
                continue
            rel = full[len(root_path):] if full.startswith(root_path) else full.lstrip("/")
            name = rel.rstrip("/").split("/")[-1]
            if not name or name.startswith("."):
                continue
            if e["dir"]:
                if recursive and len(seen) < 500:
                    queue.append(urllib.parse.quote(full))
                continue
            if Path(name).suffix.lower() in exts and 0 < e["size"] <= max_bytes:
                e["path"], e["name"] = rel, name
                out.append(e)
    return out


def _download(acc, entry, dest):
    href = acc.root + urllib.parse.quote(entry["path"])
    tmp = dest.with_suffix(dest.suffix + ".part")
    with _request(acc, "GET", href, timeout=120) as r, open(tmp, "wb") as f:
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk)
    os.replace(tmp, dest)


# ---------------------------------------------------------------- sync

def _local_name(entry):
    return "nc_" + hashlib.sha1(entry["path"].encode("utf-8")).hexdigest()[:16] + Path(entry["name"]).suffix.lower()


def _modified_ts(entry):
    try:
        return parsedate_to_datetime(entry["modified"]).timestamp()
    except Exception:
        return 0.0


def sync():
    """Mirror the folder into the cache and submit it. Returns the number of pictures."""
    acc = Access()
    entries = list_pictures(acc)
    if not entries:
        plugin.log("No pictures found in the Nextcloud folder", level="warning")
    limit = int(_number("MaxPictures", 300, 1, 5000))
    if len(entries) > limit:
        if str(_setting("PickMode", "random")) == "newest":
            entries.sort(key=_modified_ts, reverse=True)
        else:
            random.shuffle(entries)
        entries = entries[:limit]
    CACHE_DIR.mkdir(exist_ok=True)
    keep, paths, failed = set(), [], 0
    for e in entries:
        if _shutdown_event.is_set() or not plugin.is_running():
            break
        dest = CACHE_DIR / _local_name(e)
        side = dest.with_suffix(dest.suffix + ".json")
        keep.update({dest.name, side.name})
        old = {}
        try:
            old = json.loads(side.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        if not (dest.exists() and old.get("etag") == e["etag"] and old.get("size") == e["size"]):
            try:
                _download(acc, e, dest)
            except Exception as exc:  # noqa: BLE001
                failed += 1
                plugin.log(f"Could not download {e['path']}: {exc}", level="warning")
                continue
            folder = e["path"].rsplit("/", 1)[0] if "/" in e["path"] else ""
            side.write_text(json.dumps({
                "title": Path(e["name"]).stem, "subject": folder, "provider": "Nextcloud",
                "original_url": acc.link, "etag": e["etag"], "size": e["size"],
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        paths.append(str(dest))
    if failed == len(entries) and entries:
        raise RuntimeError("No picture could be downloaded")
    if not _shutdown_event.is_set():
        for f in CACHE_DIR.glob("nc_*"):
            if f.name not in keep and not f.name.endswith(".part"):
                try:
                    f.unlink()
                except OSError:
                    pass
    if paths:
        plugin.submit_media(paths, replace_catalog=True)
    plugin.log(f"Nextcloud: {len(paths)} pictures ready" + (f", {failed} failed" if failed else ""))
    return len(paths)


def refresh(_action=None):
    if not _fetch_lock.acquire(blocking=False):
        plugin.log("A Nextcloud update is already running")
        return
    plugin.content_refresh_started("Reading the Nextcloud folder...")
    try:
        count = sync()
    except Exception as exc:  # noqa: BLE001
        plugin.content_refresh_failed(f"Nextcloud update failed: {exc}")
        plugin.log(f"Nextcloud update failed: {exc}", level="error")
    else:
        plugin.content_refresh_completed(count, "The Nextcloud pictures are up to date.")
    finally:
        _fetch_lock.release()


def test_connection(_action=None):
    try:
        acc = Access()
        entries = list_pictures(acc)
        folders = len({e["path"].rsplit("/", 1)[0] for e in entries if "/" in e["path"]})
        plugin.log(f"Nextcloud OK: {len(entries)} pictures found" + (f" in {folders} subfolders" if folders else ""))
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Nextcloud test failed: {exc}", level="error")


def main():
    plugin.on_action("refresh", refresh)
    plugin.on_action("test-connection", test_connection)
    plugin.connect_sse()
    plugin.ready()
    plugin.log("Nextcloud Share 0.1.0 started")
    first = True
    while plugin.is_running() and not _shutdown_event.is_set():
        configured = bool(str(_setting("ShareUrl", "")).strip() or str(_setting("ServerUrl", "")).strip())
        if configured:
            refresh()
        elif first:
            plugin.log("Set ShareUrl (or ServerUrl + Username) in the plugin settings.", level="warning")
        first = False
        _shutdown_event.wait(_number("RefreshMinutes", 60, 5) * 60)


if __name__ == "__main__":
    main()
