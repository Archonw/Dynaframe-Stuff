#!/usr/bin/env python3
"""
JellyfinNowPlaying plugin for Dynaframe Pro.

Asks a Jellyfin server every few seconds what a chosen user is watching right now and offers the
matching cover (movie poster, series poster for episodes, album art for music) to Dynaframe as an
image source. Like other image source plugins it appears in Dynaframe as a source/playlist
("Jellyfin Now Playing"); its cover only takes part in the slideshow while that source is selected.

- Something is playing -> exactly one image is in the plugin's catalog: the cover.
- Nothing is playing   -> the last cover (or a placeholder) stays in the catalog and in the takeover
  playlist, but nothing takes the screen: your other playlists simply carry on (leave the plugin's
  own source switched off in Quick Mix if you only want the takeover).

Takeover (v0.2): the plugin keeps a saved playlist "Jellyfin (takeover)" that holds only the cover of
what is playing. While that playlist is switched ON (Choose Playlist > Saved Playlists) and the user
is watching something, the plugin takes the whole screen (display session) and shows the cover; the
other playlists wait. When playback ends the screen is handed back and they carry on. Switch the
playlist OFF and the takeover is off; the cover then only takes its turn as an image source.

Only the Python standard library is used (playback_guard.py, copied from the Tempest Weather plugin,
is optional and needs "requests").
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass
_crash_log_path = os.path.join(_plugin_dir, "crash.log")


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(_crash_log_path, "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from dynaframe_plugin_base import create_plugin

plugin = create_plugin()

try:
    import playback_guard  # optional: restarts the owner's Quick Mix if Dynaframe does not
except Exception:  # noqa: BLE001
    playback_guard = None

CACHE_DIR = Path(_plugin_dir) / "cache"
_shutdown_event = threading.Event()
_sync_lock = threading.Lock()
_state = {"item_key": None, "had_cover": False}
DATA_DIR = Path(_plugin_dir) / "data"
TAKEOVER_PLAYLIST_NAME = "Jellyfin (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Made by the Jellyfin Now Playing plugin. Switch it ON to let the cover "
                                 "take the whole screen while the chosen user is watching; OFF to disable that.")
_take = {"handle": None, "loaded": None}   # loaded = cover file name currently in the playlist
_take_lock = threading.RLock()


# ---------------------------------------------------------------- settings helpers

def _setting(name, default=""):
    try:
        value = plugin.get_setting(name, default)
    except Exception:
        return default
    return default if value is None else value


def _bool(name, default):
    return str(_setting(name, default)).strip().lower() in ("1", "true", "yes", "on")


def _number(name, default, minimum):
    try:
        return max(minimum, float(_setting(name, default)))
    except (TypeError, ValueError):
        return max(minimum, float(default))


def _server_url():
    url = str(_setting("ServerUrl", "")).strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    return url


# ---------------------------------------------------------------- Jellyfin access

def _headers():
    key = str(_setting("ApiKey", "")).strip()
    return {
        "Authorization": f'MediaBrowser Client="Dynaframe", Device="Dynaframe", '
                         f'DeviceId="dynaframe-jellyfin", Version="0.1.0", Token="{key}"',
        "X-Emby-Token": key,
        "Accept": "application/json",
    }


def _get(path, binary=False, timeout=15):
    req = urllib.request.Request(_server_url() + path, headers=_headers())
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    return data if binary else json.loads(data.decode("utf-8"))


def find_now_playing():
    """Return (session, item) of the watched user's most recently active playing session, or (None, None)."""
    user = str(_setting("UserName", "")).strip().lower()
    if not user:
        raise RuntimeError("UserName is not set")
    sessions = _get("/Sessions?activeWithinSeconds=960")
    show_paused = _bool("ShowWhenPaused", True)
    show_music = _bool("IncludeMusic", False)
    best = None
    for s in sessions:
        if str(s.get("UserName", "")).lower() != user:
            continue
        item = s.get("NowPlayingItem")
        if not item:
            continue
        if item.get("Type") == "Audio" and not show_music:
            continue
        if (s.get("PlayState") or {}).get("IsPaused") and not show_paused:
            continue
        if best is None or str(s.get("LastActivityDate", "")) > str(best[0].get("LastActivityDate", "")):
            best = (s, item)
    return best if best else (None, None)


def cover_request(item):
    """Choose which Jellyfin image to use. Returns (item_id, image_tag, cache_key)."""
    typ = item.get("Type")
    series_mode = str(_setting("EpisodeCover", "series")) == "series"
    if typ == "Episode" and series_mode and item.get("SeriesId"):
        return item["SeriesId"], item.get("SeriesPrimaryImageTag"), item["SeriesId"]
    if typ == "Audio" and item.get("AlbumId"):
        return item["AlbumId"], item.get("AlbumPrimaryImageTag"), item["AlbumId"]
    tag = (item.get("ImageTags") or {}).get("Primary")
    return item["Id"], tag, item["Id"]


def _display_title(item):
    typ = item.get("Type")
    if typ == "Episode":
        season, ep = item.get("ParentIndexNumber"), item.get("IndexNumber")
        code = f" S{season:02d}E{ep:02d}" if isinstance(season, int) and isinstance(ep, int) else ""
        return f"{item.get('SeriesName', '')}{code} - {item.get('Name', '')}".strip(" -")
    if typ == "Audio":
        return f"{item.get('Artists', [''])[0] if item.get('Artists') else ''} - {item.get('Name', '')}".strip(" -")
    year = item.get("ProductionYear")
    return f"{item.get('Name', '')} ({year})" if year else str(item.get("Name", ""))


# ---------------------------------------------------------------- cache + submit

def _clear_cache():
    CACHE_DIR.mkdir(exist_ok=True)
    for f in CACHE_DIR.glob("jellyfin_*"):
        try:
            f.unlink()
        except OSError:
            pass


def _download_cover(item):
    image_id, tag, key = cover_request(item)
    height = int(_number("ImageMaxHeight", 1080, 200))
    query = {"maxHeight": height, "quality": 90}
    if tag:
        query["tag"] = tag
    data = _get(f"/Items/{image_id}/Images/Primary?{urllib.parse.urlencode(query)}", binary=True, timeout=30)
    if len(data) < 1000:
        raise RuntimeError("Jellyfin returned an empty image")
    ext = ".png" if data[:8] == b"\x89PNG\r\n\x1a\n" else ".jpg"
    CACHE_DIR.mkdir(exist_ok=True)
    path = CACHE_DIR / f"jellyfin_{key}{ext}"
    path.write_bytes(data)
    sidecar = {
        "title": _display_title(item),
        "description": (item.get("Overview") or "")[:500],
        "subject": item.get("Type"),
        "provider": "Jellyfin",
        "original_url": f"{_server_url()}/web/index.html#!/details?id={item.get('Id')}",
    }
    path.with_suffix(path.suffix + ".json").write_text(
        json.dumps(sidecar, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


# ---------------------------------------------------------------- engine access (takeover)

class EngineError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def _engine_url():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def _engine_headers():
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    cred = str(getattr(plugin, "plugin_credential", "") or "")
    gen = str(getattr(plugin, "process_generation", "") or "")
    if cred:
        h["X-Dfr-Plugin-Credential"] = cred
    if gen:
        h["X-Dfr-Plugin-Generation"] = gen
    return h


def engine_call(method, path, payload=None, timeout=20):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(_engine_url() + path, data=data, method=method, headers=_engine_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        raise EngineError(f"{method} {path} returned HTTP {exc.code} {body}", status=exc.code) from exc
    except (urllib.error.URLError, OSError) as exc:
        raise EngineError(f"{method} {path} failed: {exc}") from exc
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except ValueError:
        return None


def _load_state():
    try:
        return json.loads((DATA_DIR / "state.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_state(**kv):
    st = _load_state()
    st.update(kv)
    try:
        DATA_DIR.mkdir(exist_ok=True)
        (DATA_DIR / "state.json").write_text(json.dumps(st), encoding="utf-8")
    except OSError:
        pass


def _find_media_id(path, wait_seconds=20):
    """The Engine's id of a file submit_media has registered (it may take a moment)."""
    target = str(path)
    deadline = time.monotonic() + wait_seconds
    q = urllib.parse.urlencode({"directories": str(CACHE_DIR)})

    def walk(node):
        if isinstance(node, dict):
            fp = node.get("filePath") or node.get("path")
            if fp == target:
                for k in ("mediaFileId", "id"):
                    if node.get(k) is not None:
                        return node[k]
            for v in node.values():
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(node, list):
            for v in node:
                r = walk(v)
                if r is not None:
                    return r
        return None

    while True:
        try:
            found = walk(engine_call("GET", f"/media/database/by-directory?{q}"))
            if found is not None:
                return found
        except EngineError as exc:
            plugin.log(f"Media lookup: {exc}", level="warning")
        if time.monotonic() >= deadline or _shutdown_event.is_set():
            return None
        _shutdown_event.wait(1.5)


def _playlist_id_of(obj):
    return (obj or {}).get("id") or ((obj or {}).get("playlist") or {}).get("id")


def _ensure_playlist():
    """Id of the takeover playlist; (re)made switched off if it does not exist."""
    pid = _load_state().get("playlistId")
    if pid:
        try:
            engine_call("GET", f"/playlists/{pid}")
            return pid
        except EngineError as exc:
            if exc.status != 404:
                raise
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION})
    pid = _playlist_id_of(created)
    if not pid:
        raise EngineError("The frame did not make the takeover playlist")
    engine_call("PUT", f"/playlists/{pid}", {"isEnabled": False})  # a new playlist joins the mix when on
    _save_state(playlistId=pid)
    _take["loaded"] = None
    plugin.log(f"Made the playlist {TAKEOVER_PLAYLIST_NAME} ({pid}), switched off. "
               "Switch it on under Choose Playlist to let the cover take the screen.")
    return pid


def _playlist_items(pid):
    items = engine_call("GET", f"/playlists/{pid}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return items


def _clear_playlist(pid):
    """Remove all items. Falls back to remaking the playlist (keeping its on/off state)."""
    items = _playlist_items(pid)
    if not items:
        return pid
    try:
        for it in items:
            engine_call("DELETE", f"/playlists/{pid}/items/{it['id']}")
        return pid
    except (EngineError, KeyError):
        pass
    info = engine_call("GET", f"/playlists/{pid}") or {}
    was_on = info.get("isEnabled") is not False
    engine_call("DELETE", f"/playlists/{pid}")
    _save_state(playlistId=None)
    new = _ensure_playlist()
    if was_on:
        engine_call("PUT", f"/playlists/{new}", {"isEnabled": True})
    return new


def _load_cover(pid, path):
    """Put exactly the cover into the takeover playlist. Returns the (possibly new) playlist id."""
    media_id = _find_media_id(path)
    if media_id is None:
        raise EngineError("The frame has not registered the cover image yet")
    pid = _clear_playlist(pid)
    errors = []
    for body in ({"mediaFileId": media_id, "customDurationSeconds": 4 * 3600},
                 {"contentType": "media", "mediaFileId": media_id, "customDurationSeconds": 4 * 3600},
                 {"filePath": str(path), "customDurationSeconds": 4 * 3600}):
        try:
            engine_call("POST", f"/playlists/{pid}/items", body)
            return pid
        except EngineError as exc:
            errors.append(str(exc))
    raise EngineError("Could not add the cover to the playlist: " + " | ".join(errors))


def _on_session_state(h):
    if str(getattr(h, "state", h)).strip().lower() in ("preempted", "expired", "failed", "released"):
        with _take_lock:
            if _take["handle"] is h or not hasattr(h, "state"):
                _take["handle"] = None


def release_takeover(reason="done"):
    with _take_lock:
        handle, _take["handle"] = _take["handle"], None
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Could not hand the screen back: {exc}", level="warning")
    plugin.log(f"Handed the screen back ({reason}).")
    if playback_guard is not None:
        threading.Thread(target=lambda: playback_guard.restore_if_stalled(
            _engine_url(), _engine_headers, plugin.log, stop_event=_shutdown_event), daemon=True).start()
    return True


def _idle_cover():
    """The image to keep in the playlist while nothing plays: the last cover, else a placeholder.

    Dynaframe only shows the on/off switch of a playlist that has at least one item, so the
    playlist is never left empty.
    """
    last = _state.get("cover_path")
    if last and Path(last).exists():
        return Path(last)
    CACHE_DIR.mkdir(exist_ok=True)
    for f in sorted(CACHE_DIR.glob("jellyfin_*")):
        if f.suffix.lower() in (".jpg", ".png"):
            return f
    src = Path(_plugin_dir) / "assets" / "idle.png"
    if not src.exists():
        return None
    dst = CACHE_DIR / "jellyfin_idle.png"
    dst.write_bytes(src.read_bytes())
    plugin.submit_media([str(dst)], replace_catalog=True)
    return dst


def _prepare_idle_playlist():
    if not _bool("Takeover", True):
        return
    path = _idle_cover()
    if path is None:
        return
    name = path.name
    pid = _ensure_playlist()
    if _take["loaded"] != name:
        _load_cover(pid, path)
        _take["loaded"] = name
        plugin.log(f"{TAKEOVER_PLAYLIST_NAME} holds {name} while nothing is playing.")


def apply_takeover(cover_path):
    """Called after every poll. cover_path is None when nothing is playing."""
    with _take_lock:
        if cover_path is None:
            release_takeover("nothing playing")
            _prepare_idle_playlist()
            return
        if not _bool("Takeover", True):
            release_takeover("takeover off")
            return
        if "display-sessions-v1" not in (getattr(plugin, "features", None) or {"display-sessions-v1"}):
            return
        pid = _ensure_playlist()
        name = Path(cover_path).name
        if _take["loaded"] != name:
            release_takeover("new cover")
            pid = _load_cover(pid, cover_path)
            _take["loaded"] = name
            plugin.log(f"Cover loaded into {TAKEOVER_PLAYLIST_NAME}.")
        info = engine_call("GET", f"/playlists/{pid}") or {}
        if info.get("isEnabled") is False:
            release_takeover("playlist switched off")
            return
        if _take["handle"] is not None:
            return
        status = engine_call("GET", "/display-sessions/status") or {}
        if status.get("active"):
            return  # another plugin has the screen
        handle = plugin.acquire_display_session(
            session_key="jellyfin-now-playing",
            state={"playback": {"kind": "playlist", "playlistId": pid, "isRunning": True},
                   "settings": {"durationSeconds": 3600, "transitionDurationMs": 400, "randomizeOrder": False},
                   "overlay": {"enabled": _bool("ShowOverlay", False)}},
            display_name="Jellyfin Now Playing",
            max_duration_seconds=4 * 3600,
            wake_if_off=False)
        if handle is None:
            plugin.log("The frame did not give up the screen (Allow takeover off for this plugin, "
                       "or another plugin has it).", level="warning")
            return
        _take["handle"] = handle
        try:
            handle.on_state_change(_on_session_state)
        except Exception:  # noqa: BLE001
            pass
        try:
            if not handle.wait_until_active(timeout=10):
                release_takeover("failed")
                return
        except Exception:  # noqa: BLE001
            release_takeover("failed")
            raise
        plugin.log("The cover is on the whole screen.")


def sync_once():
    """One poll: update the catalog if what is playing has changed. Returns the item count."""
    if not _sync_lock.acquire(blocking=False):
        return None
    try:
        _session, item = find_now_playing()
        key = None if item is None else item.get("Id")
        if key == _state["item_key"]:
            _safe_takeover(_state.get("cover_path") if key else None)
            return 1 if key else 0
        if item is None:
            _state["item_key"] = None
            _safe_takeover(None)   # hands the screen back; the last cover stays (playlist keeps an item)
            return 1 if _state.get("cover_path") else 0
        plugin.log(f"Now playing: {_display_title(item)}")
        path = _download_cover(item)
        for f in CACHE_DIR.glob("jellyfin_*"):
            if f.name != path.name and f.name != path.name + ".json":
                try:
                    f.unlink()
                except OSError:
                    pass
        plugin.submit_media([str(path)], replace_catalog=True)
        _state["item_key"] = key
        _state["had_cover"] = True
        _state["cover_path"] = str(path)
        _safe_takeover(str(path))
        return 1
    finally:
        _sync_lock.release()


def _safe_takeover(cover_path):
    try:
        apply_takeover(cover_path)
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Takeover problem: {exc}", level="warning")


def refresh(_action=None):
    plugin.content_refresh_started("Checking Jellyfin...")
    try:
        count = sync_once()
    except Exception as exc:
        plugin.content_refresh_failed(f"Jellyfin check failed: {exc}")
        plugin.log(f"Jellyfin check failed: {exc}", level="error")
    else:
        plugin.content_refresh_completed(count or 0, "Jellyfin is up to date.")


def test_connection(_action=None):
    try:
        info = _get("/System/Info/Public")
        _s, item = find_now_playing()
        msg = f"Connected to {info.get('ServerName', 'Jellyfin')} {info.get('Version', '')}. "
        msg += f"Now playing: {_display_title(item)}" if item else "Nothing is playing for this user."
        plugin.log(msg)
    except Exception as exc:
        plugin.log(f"Test failed: {exc}", level="error")


def main():
    plugin.on_action("refresh", refresh)
    plugin.on_action("test-connection", test_connection)
    plugin.connect_sse()
    plugin.ready()
    plugin.log("Jellyfin Now Playing 0.2.0 started")
    if not _server_url() or not str(_setting("ApiKey", "")).strip():
        plugin.log("Set ServerUrl, ApiKey and UserName in the plugin settings.", level="warning")
    failures = 0
    while plugin.is_running() and not _shutdown_event.is_set():
        if not plugin.is_running():
            break
        if _server_url() and str(_setting("ApiKey", "")).strip():
            try:
                sync_once()
                failures = 0
            except Exception as exc:
                failures += 1
                if failures in (1, 10) or failures % 60 == 0:
                    plugin.log(f"Jellyfin not reachable / error: {exc}", level="warning")
        _shutdown_event.wait(_number("PollSeconds", 10, 3))
    release_takeover("stopping")


if __name__ == "__main__":
    main()
