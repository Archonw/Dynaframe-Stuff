#!/usr/bin/env python3
"""
JellyfinNowPlaying plugin for Dynaframe Pro.

Asks a Jellyfin server every few seconds what a chosen user is watching right now and offers the
matching cover (movie poster, series poster for episodes, album art for music) to Dynaframe as an
image source. Like other image source plugins it appears in Dynaframe as a source/playlist
("Jellyfin Now Playing"); its cover only takes part in the slideshow while that source is selected.

- Something is playing -> exactly one image is in the plugin's catalog: the cover.
- Nothing is playing   -> depending on WhenIdle the catalog is emptied (the other selected
  playlists simply carry on) or the last cover is kept.

Only the Python standard library is used.
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass
_crash_log_path = os.path.join(_plugin_dir, "crash.log")


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(_crash_log_path, "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from dynaframe_plugin_base import create_plugin

plugin = create_plugin()

CACHE_DIR = Path(_plugin_dir) / "cache"
_shutdown_event = threading.Event()
_sync_lock = threading.Lock()
_state = {"item_key": None, "had_cover": False}


# ---------------------------------------------------------------- settings helpers

def _setting(name, default=""):
    try:
        value = plugin.get_setting(name, default)
    except Exception:
        return default
    return default if value is None else value


def _bool(name, default):
    return str(_setting(name, default)).strip().lower() in ("1", "true", "yes", "on")


def _number(name, default, minimum):
    try:
        return max(minimum, float(_setting(name, default)))
    except (TypeError, ValueError):
        return max(minimum, float(default))


def _server_url():
    url = str(_setting("ServerUrl", "")).strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    return url


# ---------------------------------------------------------------- Jellyfin access

def _headers():
    key = str(_setting("ApiKey", "")).strip()
    return {
        "Authorization": f'MediaBrowser Client="Dynaframe", Device="Dynaframe", '
                         f'DeviceId="dynaframe-jellyfin", Version="0.1.0", Token="{key}"',
        "X-Emby-Token": key,
        "Accept": "application/json",
    }


def _get(path, binary=False, timeout=15):
    req = urllib.request.Request(_server_url() + path, headers=_headers())
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    return data if binary else json.loads(data.decode("utf-8"))


def find_now_playing():
    """Return (session, item) of the watched user's most recently active playing session, or (None, None)."""
    user = str(_setting("UserName", "")).strip().lower()
    if not user:
        raise RuntimeError("UserName is not set")
    sessions = _get("/Sessions?activeWithinSeconds=960")
    show_paused = _bool("ShowWhenPaused", True)
    show_music = _bool("IncludeMusic", False)
    best = None
    for s in sessions:
        if str(s.get("UserName", "")).lower() != user:
            continue
        item = s.get("NowPlayingItem")
        if not item:
            continue
        if item.get("Type") == "Audio" and not show_music:
            continue
        if (s.get("PlayState") or {}).get("IsPaused") and not show_paused:
            continue
        if best is None or str(s.get("LastActivityDate", "")) > str(best[0].get("LastActivityDate", "")):
            best = (s, item)
    return best if best else (None, None)


def cover_request(item):
    """Choose which Jellyfin image to use. Returns (item_id, image_tag, cache_key)."""
    typ = item.get("Type")
    series_mode = str(_setting("EpisodeCover", "series")) == "series"
    if typ == "Episode" and series_mode and item.get("SeriesId"):
        return item["SeriesId"], item.get("SeriesPrimaryImageTag"), item["SeriesId"]
    if typ == "Audio" and item.get("AlbumId"):
        return item["AlbumId"], item.get("AlbumPrimaryImageTag"), item["AlbumId"]
    tag = (item.get("ImageTags") or {}).get("Primary")
    return item["Id"], tag, item["Id"]


def _display_title(item):
    typ = item.get("Type")
    if typ == "Episode":
        season, ep = item.get("ParentIndexNumber"), item.get("IndexNumber")
        code = f" S{season:02d}E{ep:02d}" if isinstance(season, int) and isinstance(ep, int) else ""
        return f"{item.get('SeriesName', '')}{code} - {item.get('Name', '')}".strip(" -")
    if typ == "Audio":
        return f"{item.get('Artists', [''])[0] if item.get('Artists') else ''} - {item.get('Name', '')}".strip(" -")
    year = item.get("ProductionYear")
    return f"{item.get('Name', '')} ({year})" if year else str(item.get("Name", ""))


# ---------------------------------------------------------------- cache + submit

def _clear_cache():
    CACHE_DIR.mkdir(exist_ok=True)
    for f in CACHE_DIR.glob("jellyfin_*"):
        try:
            f.unlink()
        except OSError:
            pass


def _download_cover(item):
    image_id, tag, key = cover_request(item)
    height = int(_number("ImageMaxHeight", 1080, 200))
    query = {"maxHeight": height, "quality": 90}
    if tag:
        query["tag"] = tag
    data = _get(f"/Items/{image_id}/Images/Primary?{urllib.parse.urlencode(query)}", binary=True, timeout=30)
    if len(data) < 1000:
        raise RuntimeError("Jellyfin returned an empty image")
    ext = ".png" if data[:8] == b"\x89PNG\r\n\x1a\n" else ".jpg"
    CACHE_DIR.mkdir(exist_ok=True)
    path = CACHE_DIR / f"jellyfin_{key}{ext}"
    path.write_bytes(data)
    sidecar = {
        "title": _display_title(item),
        "description": (item.get("Overview") or "")[:500],
        "subject": item.get("Type"),
        "provider": "Jellyfin",
        "original_url": f"{_server_url()}/web/index.html#!/details?id={item.get('Id')}",
    }
    path.with_suffix(path.suffix + ".json").write_text(
        json.dumps(sidecar, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def sync_once():
    """One poll: update the catalog if what is playing has changed. Returns the item count."""
    if not _sync_lock.acquire(blocking=False):
        return None
    try:
        _session, item = find_now_playing()
        key = None if item is None else item.get("Id")
        if key == _state["item_key"]:
            return 1 if key else 0
        if item is None:
            _state["item_key"] = None
            if str(_setting("WhenIdle", "empty")) == "keep":
                return 1 if _state["had_cover"] else 0
            plugin.log("Nothing is playing - cover removed")
            _clear_cache()
            plugin.submit_media([], replace_catalog=True)
            _state["had_cover"] = False
            return 0
        plugin.log(f"Now playing: {_display_title(item)}")
        path = _download_cover(item)
        for f in CACHE_DIR.glob("jellyfin_*"):
            if f.name != path.name and f.name != path.name + ".json":
                try:
                    f.unlink()
                except OSError:
                    pass
        plugin.submit_media([str(path)], replace_catalog=True)
        _state["item_key"] = key
        _state["had_cover"] = True
        return 1
    finally:
        _sync_lock.release()


def refresh(_action=None):
    plugin.content_refresh_started("Checking Jellyfin...")
    try:
        count = sync_once()
    except Exception as exc:
        plugin.content_refresh_failed(f"Jellyfin check failed: {exc}")
        plugin.log(f"Jellyfin check failed: {exc}", level="error")
    else:
        plugin.content_refresh_completed(count or 0, "Jellyfin is up to date.")


def test_connection(_action=None):
    try:
        info = _get("/System/Info/Public")
        _s, item = find_now_playing()
        msg = f"Connected to {info.get('ServerName', 'Jellyfin')} {info.get('Version', '')}. "
        msg += f"Now playing: {_display_title(item)}" if item else "Nothing is playing for this user."
        plugin.log(msg)
    except Exception as exc:
        plugin.log(f"Test failed: {exc}", level="error")


def main():
    plugin.on_action("refresh", refresh)
    plugin.on_action("test-connection", test_connection)
    plugin.connect_sse()
    plugin.ready()
    if not _server_url() or not str(_setting("ApiKey", "")).strip():
        plugin.log("Set ServerUrl, ApiKey and UserName in the plugin settings.", level="warning")
    failures = 0
    while plugin.is_running() and not _shutdown_event.is_set():
        if _server_url() and str(_setting("ApiKey", "")).strip():
            try:
                sync_once()
                failures = 0
            except Exception as exc:
                failures += 1
                if failures in (1, 10) or failures % 60 == 0:
                    plugin.log(f"Jellyfin not reachable / error: {exc}", level="warning")
        _shutdown_event.wait(_number("PollSeconds", 10, 3))


if __name__ == "__main__":
    main()
