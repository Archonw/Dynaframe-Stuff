"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/TravelMap/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PhotoSeconds", "PhotoPause", "RefreshHours", "PlaylistSeconds"];
const CHECK_FIELDS = ["Cluster", "ShowLegend", "ShowPhotos", "MapPan", "PlaceNames"];
const SELECT_FIELDS = ["Layout", "Region", "PhotoSize", "ThreadWidth"];
const TEXT_FIELDS = ["ServerUrl", "Title", "Folders"];
const KINDS = ["library", "playlist", "immich_album", "immich_all"];
const PINS = ["pin", "tack", "flag", "needle"];
let current = null;
let editing = false;
let collections = [];
let renderedCollections = "";
let palette = ["#b3261e", "#1f4e8c", "#2e6b34", "#c9922b", "#6b3d82", "#1f7a7a", "#c45a24", "#2b2b2b"];
const lists = { playlist: null, immich_album: null };
const listErrors = { playlist: "", immich_album: "" };

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Reisekarte", "Travel Map", "Mapa de viajes"],
  lede: ["Eine Weltkarte im Stil eines alten Globus, mit Stecknadeln an den Orten, an denen deine Fotos entstanden sind. Die Orte stammen aus den GPS-Daten der Fotos. Jede Änderung hier wird sofort gespeichert.",
    "A world map in the style of an old globe, with push pins where your photos were taken. The places come from the photos' GPS data. Every change here is saved immediately.",
    "Un mapa del mundo al estilo de un globo antiguo, con chinchetas donde se tomaron tus fotos. Los lugares salen de los datos GPS de las fotos. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Fotos neu einlesen", "Read photos again", "Volver a leer las fotos"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factNow: ["Gerade", "Now", "Ahora"],
  factPins: ["Auf der Karte", "On the map", "En el mapa"],
  factRead: ["Zuletzt eingelesen", "Last read", "Última lectura"],
  factVersion: ["Version", "Version", "Versión"],
  nowBusy: ["Liest Fotos ein …", "Reading photos …", "Leyendo fotos …"],
  nowIdle: ["Bereit", "Ready", "Listo"],
  pinsState: ["{photos} Fotos an {places} Orten", "{photos} photos at {places} places", "{photos} fotos en {places} lugares"],
  pinsTitle: ["Nadeln", "Pins", "Chinchetas"],
  pinsHint: ["Jede Zeile ist eine Sammlung von Fotos mit eigener Nadel. Fotos ohne GPS-Daten bekommen keine Nadel.",
    "Each row is a collection of photos with its own pin. Photos without GPS data get no pin.",
    "Cada fila es una colección de fotos con su propia chincheta. Las fotos sin datos GPS no reciben chincheta."],
  add: ["Sammlung hinzufügen", "Add collection", "Añadir colección"],
  remove: ["Entfernen", "Remove", "Quitar"],
  kind: ["Fotos aus", "Photos from", "Fotos de"],
  kind_library: ["Alle Fotos in DynaFrame", "All photos in DynaFrame", "Todas las fotos de DynaFrame"],
  kind_playlist: ["Einer Playlist von DynaFrame", "A DynaFrame playlist", "Una lista de DynaFrame"],
  kind_immich_album: ["Einem Immich-Album", "An Immich album", "Un álbum de Immich"],
  kind_immich_all: ["Allen Fotos in Immich", "All photos in Immich", "Todas las fotos de Immich"],
  ref_playlist: ["Playlist", "Playlist", "Lista"],
  ref_immich_album: ["Album", "Album", "Álbum"],
  ref_none: ["Keine Auswahl nötig", "Nothing to pick", "Nada que elegir"],
  pick: ["Bitte wählen …", "Please pick …", "Elige …"],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  label: ["Name in der Legende", "Name in the legend", "Nombre en la leyenda"],
  labelPlaceholder: ["z. B. Sommerurlaube", "e.g. Summer holidays", "p. ej. Vacaciones de verano"],
  color: ["Farbe", "Colour", "Color"],
  pin_pin: ["Stecknadel", "Push pin", "Alfiler"],
  pin_tack: ["Reißzwecke", "Thumbtack", "Chincheta"],
  pin_flag: ["Fähnchen", "Flag", "Banderita"],
  pin_needle: ["Lange Nadel", "Long pin", "Aguja larga"],
  colBusy: ["Wird eingelesen …", "Reading …", "Leyendo …"],
  colWait: ["Wartet auf das Einlesen …", "Waiting to be read …", "Esperando la lectura …"],
  colOk: ["{located} von {total} Fotos haben einen Ort.", "{located} of {total} photos have a location.", "{located} de {total} fotos tienen ubicación."],
  colOkImmich: ["{located} Fotos mit Ort.", "{located} photos with a location.", "{located} fotos con ubicación."],
  max: ["Mehr als acht Sammlungen gehen nicht.", "No more than eight collections.", "No caben más de ocho colecciones."],
  mapTitle: ["Karte", "Map", "Mapa"],
  layout: ["Im Querformat", "In landscape", "En horizontal"],
  layoutOval: ["Ovale Weltkarte", "Oval world map", "Mapa del mundo ovalado"],
  layoutGlobes: ["Drei Globen", "Three globes", "Tres globos"],
  region: ["Ausschnitt", "Area", "Zona"],
  regionWorld: ["Die ganze Welt", "The whole world", "Todo el mundo"],
  regionAuto: ["Nur wo Nadeln stecken", "Only where pins are", "Solo donde hay chinchetas"],
  title: ["Titel auf der Karte", "Title on the map", "Título en el mapa"],
  titlePlaceholder: ["Unsere Reisen", "Our Travels", "Nuestros viajes"],
  layoutHint: ["Im Hochformat zeigt die Karte immer drei Globen übereinander.",
    "In portrait the map always shows three globes stacked.",
    "En vertical el mapa muestra siempre tres globos."],
  cluster: ["Nahe Nadeln zusammenfassen", "Merge pins that are close", "Agrupar chinchetas cercanas"],
  legend: ["Legende zeigen", "Show legend", "Mostrar leyenda"],
  photos: ["Ab und zu ein Foto an seiner Nadel zeigen", "Now and then show a photo at its pin", "De vez en cuando mostrar una foto junto a su chincheta"],
  photoSeconds: ["Foto zeigen für … Sekunden", "Show a photo for … seconds", "Mostrar una foto … segundos"],
  photoPause: ["Pause zwischen zwei Fotos (Sekunden)", "Pause between two photos (seconds)", "Pausa entre dos fotos (segundos)"],
  photoSize: ["Fotogröße", "Photo size", "Tamaño de la foto"],
  sizeS: ["Klein", "Small", "Pequeña"],
  sizeM: ["Mittel", "Medium", "Mediana"],
  sizeL: ["Groß", "Large", "Grande"],
  sizeXL: ["Sehr groß", "Extra large", "Muy grande"],
  threadWidth: ["Dicke des roten Fadens", "Width of the red thread", "Grosor del hilo rojo"],
  threadThin: ["Dünn", "Thin", "Fino"],
  threadNormal: ["Normal", "Normal", "Normal"],
  threadThick: ["Dick", "Thick", "Grueso"],
  threadXThick: ["Sehr dick", "Extra thick", "Muy grueso"],
  mapPan: ["Für jedes Foto die Karte zur Seite rücken", "Move the map aside for each photo", "Desplazar el mapa a un lado para cada foto"],
  placeNames: ["Ortsnamen bei OpenStreetMap nachschlagen", "Look up place names on OpenStreetMap", "Buscar nombres de lugares en OpenStreetMap"],
  placeHint: ["Fotos aus DynaFrame kennen nur ihre Koordinaten. Für die Bildunterschrift fragt das Plugin dann OpenStreetMap nach dem Ort, höchstens einmal pro Sekunde, und merkt sich die Antwort. Immich liefert den Ort selbst.",
    "Photos from DynaFrame only know their coordinates. For the caption the plugin asks OpenStreetMap for the place, at most once a second, and remembers the answer. Immich supplies the place itself.",
    "Las fotos de DynaFrame solo conocen sus coordenadas. Para el pie de foto el plugin pregunta el lugar a OpenStreetMap, como mucho una vez por segundo, y guarda la respuesta. Immich ya da el lugar."],
  refreshHours: ["Neue Fotos suchen alle … Stunden", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverHint: ["Nur nötig, wenn eine Sammlung von Immich kommt.", "Only needed when a collection comes from Immich.", "Solo hace falta si una colección viene de Immich."],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  keySaved: ["gespeichert – leer lassen zum Behalten", "saved – leave empty to keep", "guardada; déjala vacía para conservarla"],
  keyMissing: ["noch keiner", "none yet", "aún ninguna"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  testing: ["Teste …", "Testing …", "Probando …"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo conseguir una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reichen <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code> und <code>map.read</code>; mit <b>Alle</b> geht es auch. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich, click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code> and <code>map.read</code> are enough; <b>All</b> works too. The key stays in the plugin on the frame.",
    "En Immich, pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code> y <code>map.read</code>; con <b>Todos</b> también funciona. La clave se queda en el plugin del marco."],
  foldersTitle: ["Weitere Ordner auf dem Rahmen", "More folders on the frame", "Más carpetas en el marco"],
  foldersHint: ["Für die Sammlung „Alle Fotos in DynaFrame“: Das Plugin fragt DynaFrame nach seiner Mediendatenbank und den Medienordnern. Liegen Fotos woanders (z. B. ein eingehängtes NAS), trag die Ordner hier ein, einen pro Zeile.",
    "For the collection “All photos in DynaFrame”: the plugin asks DynaFrame for its media database and media folders. If photos live elsewhere (e.g. a mounted NAS), enter the folders here, one per line.",
    "Para la colección «Todas las fotos de DynaFrame»: el plugin pide a DynaFrame su base de medios y sus carpetas. Si hay fotos en otro sitio (p. ej. un NAS montado), escribe aquí las carpetas, una por línea."],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  renderedCollections = "";
  if (current) renderCollections();
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Nadeln zeichnen
// (dieselben Formen wie in der Szene)
function shade(hex, f) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

function ball(ctx, x, y, r, color) {
  const g = ctx.createRadialGradient(x - r * 0.38, y - r * 0.42, r * 0.08, x, y, r);
  g.addColorStop(0, shade(color, 0.65));
  g.addColorStop(0.35, color);
  g.addColorStop(1, shade(color, -0.55));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,.75)";
  ctx.beginPath(); ctx.ellipse(x - r * 0.35, y - r * 0.4, r * 0.22, r * 0.15, -0.6, 0, Math.PI * 2); ctx.fill();
}

function needle(ctx, x0, y0, x1, y1, w) {
  const g = ctx.createLinearGradient(x0 - w, y0, x0 + w, y0);
  g.addColorStop(0, "#5d5d5d"); g.addColorStop(0.5, "#e6e6e6"); g.addColorStop(1, "#6b6b6b");
  ctx.strokeStyle = g;
  ctx.lineWidth = w;
  ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
}

function shadowLine(ctx, x, y, dx, dy, w, blur) {
  ctx.save();
  ctx.strokeStyle = "rgba(40,25,8,.28)";
  ctx.lineWidth = w;
  ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + dx, y + dy); ctx.stroke();
  ctx.fillStyle = "rgba(40,25,8,.22)";
  ctx.beginPath(); ctx.ellipse(x + dx, y + dy, blur, blur * 0.7, 0.4, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

// Die Spitze jeder Nadel sitzt genau auf (x, y).
function drawPin(ctx, kind, x, y, r, color, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  if (kind === "tack") {
    // Reißzwecke, schräg von oben
    ctx.fillStyle = "rgba(40,25,8,.3)";
    ctx.beginPath(); ctx.ellipse(x + r * 0.55, y + r * 0.2, r * 1.15, r * 0.75, 0, 0, Math.PI * 2); ctx.fill();
    const hx = x, hy = y - r * 0.55;
    ctx.fillStyle = shade(color, -0.45);
    ctx.beginPath(); ctx.ellipse(hx, hy + r * 0.18, r * 1.15, r * 0.82, 0, 0, Math.PI * 2); ctx.fill();
    const g = ctx.createRadialGradient(hx - r * 0.4, hy - r * 0.35, r * 0.1, hx, hy, r * 1.15);
    g.addColorStop(0, shade(color, 0.55)); g.addColorStop(0.5, color); g.addColorStop(1, shade(color, -0.3));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(hx, hy, r * 1.1, r * 0.78, 0, 0, Math.PI * 2); ctx.fill();
    ball(ctx, hx, hy - r * 0.08, r * 0.48, color);
  } else if (kind === "flag") {
    const top = y - r * 3.6;
    shadowLine(ctx, x, y, r * 1.8, -r * 1.1, r * 0.25, r * 0.5);
    ctx.strokeStyle = "#4a3219";
    ctx.lineWidth = Math.max(1, r * 0.22);
    ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, top); ctx.stroke();
    const fw = r * 2.1, fh = r * 1.35;
    const g = ctx.createLinearGradient(x, top, x + fw, top + fh);
    g.addColorStop(0, shade(color, 0.2)); g.addColorStop(1, shade(color, -0.25));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x, top + r * 0.1);
    ctx.bezierCurveTo(x + fw * 0.35, top - r * 0.35, x + fw * 0.65, top + r * 0.45, x + fw, top + r * 0.15);
    ctx.lineTo(x + fw * 0.82, top + fh * 0.6);
    ctx.lineTo(x + fw, top + fh + r * 0.05);
    ctx.bezierCurveTo(x + fw * 0.65, top + fh + r * 0.35, x + fw * 0.35, top + fh - r * 0.45, x, top + fh);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(40,25,8,.45)";
    ctx.lineWidth = Math.max(0.6, r * 0.08);
    ctx.stroke();
    ball(ctx, x, top - r * 0.12, r * 0.3, "#c9a24a");
  } else if (kind === "needle") {
    // Lange Glaskopfnadel, steil
    const hx = x + r * 0.55, hy = y - r * 3.4;
    shadowLine(ctx, x, y, r * 2.4, -r * 1.3, r * 0.22, r * 0.5);
    needle(ctx, x, y, hx, hy, Math.max(1, r * 0.17));
    ball(ctx, hx, hy, r * 0.62, color);
  } else {
    // Stecknadel mit rundem Kopf, leicht schräg
    const hx = x + r * 0.95, hy = y - r * 2.3;
    shadowLine(ctx, x, y, r * 2.1, -r * 0.7, r * 0.28, r * 0.85);
    needle(ctx, x, y, hx, hy, Math.max(1, r * 0.22));
    ball(ctx, hx, hy, r, color);
  }
  // Einstichpunkt
  ctx.fillStyle = "rgba(40,25,8,.55)";
  ctx.beginPath(); ctx.arc(x, y, Math.max(0.8, r * 0.14), 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

function pinCanvas(kind, color, size) {
  const c = document.createElement("canvas");
  const dpr = window.devicePixelRatio || 1;
  c.width = c.height = Math.round(size * dpr);
  const g = c.getContext("2d");
  g.scale(dpr, dpr);
  const r = size * (kind === "tack" ? 0.26 : kind === "pin" ? 0.2 : 0.17);
  const x = kind === "tack" ? size * 0.5 : kind === "needle" ? size * 0.4 : size * 0.28;
  const y = kind === "tack" ? size * 0.75 : size * 0.92;
  drawPin(g, kind, x, y, r, color);
  return c;
}

// ------------------------------------------------------------ Sammlungen

async function loadList(kind, force = false) {
  if (lists[kind] && !force) return;
  try {
    const result = await api(kind === "playlist" ? "./api/playlists" : "./api/albums");
    lists[kind] = kind === "playlist" ? result.playlists : result.albums;
    listErrors[kind] = "";
  } catch (error) {
    lists[kind] = null;
    listErrors[kind] = error.message;
  }
  refillRefs(kind);
}

// Änderungen an den Sammlungen gehen nacheinander raus, und solange eine
// unterwegs ist, überschreibt kein älterer Stand vom Plugin die Zeilen
// (sonst ging z. B. die gewählte Playlist verloren, wenn gleich danach die
// Nadel geändert wurde).
let commitChain = Promise.resolve();
let pendingCommits = 0;
let lastEdit = 0;
let lastCommitDone = 0;
function commit() {
  const snapshot = JSON.parse(JSON.stringify(collections));
  pendingCommits++;
  lastEdit = Date.now();
  commitChain = commitChain.then(() => save({ Collections: snapshot })).finally(() => { pendingCommits--; lastCommitDone = Date.now(); });
}

function needsRefOf(col) {
  return col.kind === "playlist" || col.kind === "immich_album";
}

function statusText(col) {
  const s = (current?.status || {})[col.id] || {};
  if (s.state === "busy") return [t("colBusy"), ""];
  if (s.state === "error") return [s.error || "", "bad"];
  if (s.state === "ok") {
    if (col.kind === "immich_all") return [t("colOkImmich", { located: fmt(s.located) }), "ok"];
    return [t("colOk", { located: fmt(s.located), total: fmt(s.total) }), s.located ? "ok" : ""];
  }
  return [current?.busy ? t("colWait") : "", ""];
}

function collectionsKey() {
  return JSON.stringify([collections, lists, listErrors, lang]);
}

// Auf dem Handy liegt zwischen Antippen und "click" etwas Zeit; wird die Zeile
// in der Zeit neu gebaut, geht das Tippen ins Leere. Darum werden die Zeilen
// nur neu gebaut, wenn gerade niemand damit hantiert, und Änderungen an einer
// Zeile werden an Ort und Stelle eingetragen.
let lastTouch = 0;
el("collections").addEventListener("pointerdown", () => { lastTouch = Date.now(); }, true);
el("collections").addEventListener("touchstart", () => { lastTouch = Date.now(); }, { capture: true, passive: true });

function busyRows() {
  const box = el("collections");
  return (box.contains(document.activeElement) && document.activeElement !== box) || Date.now() - lastTouch < 2500;
}

function fillRef(ref, col) {
  ref.textContent = "";
  ref.disabled = false;
  const needsRef = col.kind === "playlist" || col.kind === "immich_album";
  if (!needsRef) {
    ref.add(new Option(t("ref_none"), ""));
    ref.disabled = true;
    return;
  }
  const items = lists[col.kind];
  if (!items) {
    ref.add(new Option(listErrors[col.kind] || t("loading"), col.ref));
    if (!listErrors[col.kind]) loadList(col.kind);
    return;
  }
  ref.add(new Option(t("pick"), ""));
  for (const item of items) {
    const count = item.count ? ` (${fmt(item.count)})` : "";
    ref.add(new Option(`${item.name}${count}`, String(item.id), false, String(item.id) === col.ref));
  }
  if (col.ref && !items.some((i) => String(i.id) === col.ref)) ref.add(new Option(`#${col.ref}`, col.ref, false, true));
}

function refillRefs(kind) {
  const box = el("collections");
  for (const col of collections) {
    if (col.kind !== kind) continue;
    const ref = box.querySelector(`select[data-ref="${col.id}"]`);
    if (ref && document.activeElement !== ref) fillRef(ref, col);
  }
  if (renderedCollections) renderedCollections = collectionsKey();
}

function renderCollections() {
  const key = collectionsKey();
  const box = el("collections");
  if (key === renderedCollections) {
    // Nur die Zeilen mit dem Stand auffrischen; die Felder bleiben, wie sie sind.
    for (const col of collections) {
      const meta = box.querySelector(`[data-meta="${col.id}"]`);
      if (meta) { const [text, tone] = statusText(col); meta.textContent = text; meta.className = `meta ${tone}`; }
    }
    return;
  }
  if (renderedCollections && busyRows()) return;
  renderedCollections = key;
  box.textContent = "";
  collections.forEach((col, index) => {
    const row = document.createElement("div");
    row.className = "collection";

    const view = document.createElement("div");
    view.className = "pinview";
    view.appendChild(pinCanvas(col.pin, col.color, 44));
    row.appendChild(view);

    const kindField = document.createElement("label");
    kindField.className = "field";
    kindField.innerHTML = `<span>${t("kind")}</span>`;
    const kind = document.createElement("select");
    for (const k of KINDS) kind.add(new Option(t(`kind_${k}`), k, false, k === col.kind));
    kind.addEventListener("change", () => {
      col.kind = kind.value;
      col.ref = "";
      refLabel.innerHTML = `<span>${needsRefOf(col) ? t(`ref_${col.kind}`) : "&nbsp;"}</span>`;
      refLabel.appendChild(ref);
      fillRef(ref, col);
      renderedCollections = collectionsKey();
      commit();
    });
    kindField.appendChild(kind);
    row.appendChild(kindField);

    const refLabel = document.createElement("label");
    refLabel.className = "field";
    refLabel.innerHTML = `<span>${needsRefOf(col) ? t(`ref_${col.kind}`) : "&nbsp;"}</span>`;
    const ref = document.createElement("select");
    ref.dataset.ref = col.id;
    fillRef(ref, col);
    ref.addEventListener("change", () => {
      col.ref = ref.value;
      const item = (lists[col.kind] || []).find((i) => String(i.id) === ref.value);
      if (item && !col.name) { col.name = item.name.slice(0, 40); name.value = col.name; }
      renderedCollections = collectionsKey();
      commit();
    });
    refLabel.appendChild(ref);
    row.appendChild(refLabel);

    const nameField = document.createElement("label");
    nameField.className = "field";
    nameField.innerHTML = `<span>${t("label")}</span>`;
    const name = document.createElement("input");
    name.type = "text";
    name.maxLength = 40;
    name.value = col.name;
    name.placeholder = t("labelPlaceholder");
    name.addEventListener("change", () => { col.name = name.value.trim(); renderedCollections = collectionsKey(); commit(); });
    nameField.appendChild(name);
    row.appendChild(nameField);

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "secondary remove";
    remove.textContent = t("remove");
    remove.addEventListener("click", () => {
      collections.splice(index, 1);
      renderedCollections = "";
      renderCollections();
      commit();
    });
    row.appendChild(remove);

    const look = document.createElement("div");
    look.className = "look";
    const swatches = document.createElement("div");
    swatches.className = "swatches";
    swatches.setAttribute("role", "group");
    swatches.setAttribute("aria-label", t("color"));
    for (const color of palette) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "swatch";
      b.style.background = color;
      b.setAttribute("aria-pressed", String(color.toLowerCase() === col.color.toLowerCase()));
      b.addEventListener("click", () => {
        col.color = color;
        for (const other of swatches.children) other.setAttribute("aria-pressed", String(other === b));
        redrawPins();
        renderedCollections = collectionsKey();
        commit();
      });
      swatches.appendChild(b);
    }
    const pins = document.createElement("div");
    pins.className = "pins";
    for (const kindName of PINS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "secondary pinchoice";
      b.title = t(`pin_${kindName}`);
      b.setAttribute("aria-label", t(`pin_${kindName}`));
      b.setAttribute("aria-pressed", String(kindName === col.pin));
      b.appendChild(pinCanvas(kindName, col.color, 34));
      b.addEventListener("click", () => {
        col.pin = kindName;
        for (const other of pins.children) other.setAttribute("aria-pressed", String(other === b));
        redrawPins();
        renderedCollections = collectionsKey();
        commit();
      });
      pins.appendChild(b);
    }
    function redrawPins() {
      view.replaceChildren(pinCanvas(col.pin, col.color, 44));
      PINS.forEach((kindName, i) => pins.children[i].replaceChildren(pinCanvas(kindName, col.color, 34)));
    }
    look.append(swatches, pins);
    row.appendChild(look);

    const meta = document.createElement("p");
    const [text, tone] = statusText(col);
    meta.className = `meta ${tone}`;
    meta.dataset.meta = col.id;
    meta.textContent = text;
    row.appendChild(meta);

    box.appendChild(row);
  });
  el("addCollection").disabled = collections.length >= 8;
}

el("addCollection").addEventListener("click", () => {
  if (collections.length >= 8) { setStatus(t("max"), "bad", "collectionsNote"); return; }
  const used = new Set(collections.map((c) => c.color));
  const color = palette.find((c) => !used.has(c)) || palette[0];
  const pin = PINS[collections.length % PINS.length];
  collections.push({ id: Math.random().toString(36).slice(2, 10), kind: "playlist", ref: "", name: "", color, pin });
  renderedCollections = "";
  renderCollections();
  loadList("playlist");
  commit();
});

// ------------------------------------------------------------ Stand

function render(state, started = 0) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  palette = state.palette || palette;
  el("factNow").textContent = state.busy ? t("nowBusy") : t("nowIdle");
  el("factPins").textContent = state.photos ? t("pinsState", { photos: fmt(state.photos), places: fmt(state.places) }) : "—";
  el("factRead").textContent = clock(state.at);
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Dynaframe-Stuff/issues/new?title=" +
    encodeURIComponent(`[Travel Map ${state.version}] `);

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = s[name];
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = state.secretsSet.ApiKey ? t("keySaved") : t("keyMissing");
    }
    // Ein Stand, der abgefragt wurde, bevor die letzte Änderung gespeichert war,
    // ist veraltet und darf die Auswahl nicht zurückdrehen.
    // Nur einen wirklich anderen Stand übernehmen und dann die Zeilen neu bauen,
    // sonst hingen die Zeilen noch an den alten Einträgen.
    if (!busyRows() && !pendingCommits && started > lastCommitDone && started > lastEdit &&
        JSON.stringify(s.Collections) !== JSON.stringify(collections)) {
      collections = JSON.parse(JSON.stringify(s.Collections));
      renderedCollections = "";
    }
  }
  el("PhotoSeconds").disabled = !s.ShowPhotos;
  el("PhotoPause").disabled = !s.ShowPhotos;
  el("PhotoSize").disabled = !s.ShowPhotos;
  el("ThreadWidth").disabled = !s.ShowPhotos;
  el("MapPan").disabled = !s.ShowPhotos;
  renderCollections();
}

async function refresh() {
  try {
    const started = Date.now();
    render(await api("./api/state"), started);
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Title").addEventListener("change", (e) => save({ Title: e.target.value }));
el("Folders").addEventListener("change", (e) => save({ Folders: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) loadList("immich_album", true);
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("playlistButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/playlist", { method: "POST" });
    setStatus(result.message || "", "ok");
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh();
setInterval(refresh, 4000);
