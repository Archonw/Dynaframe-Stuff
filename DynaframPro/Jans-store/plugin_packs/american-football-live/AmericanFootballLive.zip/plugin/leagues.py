"""Die Ligen und woher ihre Ergebnisse kommen.

Eine öffentliche Quelle ohne Schlüssel: ESPN (site.api.espn.com), die
Scoreboard-Schnittstelle der ESPN-Webseite. Sie ist nicht offiziell
dokumentiert; fällt sie aus oder ändert sich, zeigt die Szene den letzten
Stand und sagt, wie alt er ist.

Eine neue Liga ist ein Eintrag in LEAGUES mit ihrem ESPN-Kürzel (siehe
https://site.api.espn.com/apis/site/v2/sports/football/<kürzel>/scoreboard).

Alles hier gibt einheitliche Spiele zurück:
  {"id", "kickoff" (Epoch-Sekunden), "state": "pre"|"live"|"post"|"off",
   "minute": "Q3 4:21" | "HZ" | "EQ1" | "OT 2:10" | "", "home": {"name","short","logo","record"},
   "away": {...}, "scoreHome", "scoreAway" (int oder None),
   "possession": "home"|"away"|"", "down": "3rd & 7 at KC 35" | ""}
"""

import re
from datetime import datetime, timezone

import requests

HTTP_HEADERS = {"User-Agent": "DynaFrame-AmericanFootballLive/0.1 (+https://github.com/Archonw/Dynaframe-Stuff)",
                "Accept": "application/json"}
TIMEOUT = (8, 20)

ESPN_SITE = "https://site.api.espn.com/apis/site/v2/sports/football"
ESPN_STANDINGS = "https://site.api.espn.com/apis/v2/sports/football"

# Reihenfolge = Reihenfolge, in der die Ligen auf der Plugin-Seite stehen.
LEAGUES = {
    "nfl":   {"name": "NFL", "espn": "nfl", "table": True, "color": "#1d4ed8"},
    "ncaaf": {"name": "College Football (Top 25)", "espn": "college-football", "table": False, "color": "#c8102e"},
    # Die großen College-Conferences: alle Spiele ihrer Teams und ihre Tabelle.
    # "groups" ist die Gruppen-Nummer bei ESPN, "conf" der Name in der Tabelle.
    "sec":   {"name": "SEC", "espn": "college-football", "groups": "8", "conf": "SEC", "table": True,
              "color": "#004b8d"},
    "b1g":   {"name": "Big Ten", "espn": "college-football", "groups": "5", "conf": "Big Ten", "table": True,
              "color": "#0088ce"},
    "b12":   {"name": "Big 12", "espn": "college-football", "groups": "4", "conf": "Big 12", "table": True,
              "color": "#c41230"},
    "acc":   {"name": "ACC", "espn": "college-football", "groups": "1", "conf": "ACC", "table": True,
              "color": "#013ca6"},
    "ufl":   {"name": "UFL", "espn": "ufl", "table": True, "color": "#0f766e"},
    "cfl":   {"name": "CFL", "espn": "cfl", "table": True, "color": "#d97706"},
}
DEFAULT_LEAGUES = ["nfl", "ncaaf"]


def display_name(league_id, lang="de"):
    """Der Name einer Liga in der eingestellten Sprache; Eigennamen bleiben."""
    league = LEAGUES[league_id]
    return league.get(f"name_{lang}") or league["name"]


class SourceError(Exception):
    """Eine Quelle hat nicht brauchbar geantwortet."""


def get_json(url, params=None):
    try:
        response = requests.get(url, params=params, headers=HTTP_HEADERS, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError(f"{url}: {exc}") from exc
    if response.status_code >= 400:
        raise SourceError(f"{url}: HTTP {response.status_code}")
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError(f"{url}: keine JSON-Antwort") from exc


def parse_time(text):
    if not text:
        return None
    try:
        moment = datetime.fromisoformat(str(text).strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.timestamp()


def as_int(value):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def team(name, short, logo, record=""):
    name = (name or "").strip() or "?"
    return {"name": name, "short": (short or "").strip() or name, "logo": logo or "", "record": record or ""}


def espn_logo(team_raw):
    if team_raw.get("logo"):
        return team_raw["logo"]
    logos = team_raw.get("logos") or []
    return (logos[0] or {}).get("href", "") if logos else ""


# --------------------------------------------------------------------------
# Spiele
# --------------------------------------------------------------------------

def game_clock(status, name):
    """Viertel und Uhr, sprachneutral: "Q3 4:21", "OT 2:10"; "HZ" in der
    Halbzeit, "EQ1" am Ende eines Viertels (die Szene übersetzt beides)."""
    period = as_int(status.get("period")) or 0
    clock = str(status.get("displayClock") or "").strip()
    if name == "STATUS_HALFTIME":
        return "HZ"
    if name == "STATUS_END_PERIOD":
        return f"EQ{period}" if 0 < period <= 4 else "EOT"
    if period <= 0:
        return ""
    quarter = f"Q{period}" if period <= 4 else ("OT" if period == 5 else f"{period - 4}OT")
    return f"{quarter} {clock}".strip()


def espn_match(event):
    competition = (event.get("competitions") or [{}])[0]
    competitors = competition.get("competitors") or []
    home = next((c for c in competitors if c.get("homeAway") == "home"), competitors[0] if competitors else {})
    away = next((c for c in competitors if c.get("homeAway") == "away"),
                competitors[1] if len(competitors) > 1 else {})
    status = competition.get("status") or event.get("status") or {}
    kind = status.get("type") or {}
    raw_state = kind.get("state")
    name = str(kind.get("name") or "")
    if name in ("STATUS_POSTPONED", "STATUS_CANCELED", "STATUS_ABANDONED", "STATUS_SUSPENDED"):
        state = "off"
    elif raw_state == "in":
        state = "live"
    elif raw_state == "post" or kind.get("completed"):
        state = "post"
    else:
        state = "pre"
    minute = ""
    if state == "live":
        minute = game_clock(status, name)
    elif state == "off":
        minute = "abgesagt" if name == "STATUS_CANCELED" else "verlegt"
    elif state == "post" and (as_int(status.get("period")) or 0) > 4:
        minute = "OT"

    def score(c):
        return as_int(c.get("score")) if state in ("live", "post") else None

    def side(c):
        t = c.get("team") or {}
        records = [r for r in c.get("records") or [] if isinstance(r, dict)]
        overall = next((r for r in records if r.get("type") in ("total", "overall")), records[0] if records else {})
        return team(t.get("displayName"), t.get("shortDisplayName") or t.get("name"), espn_logo(t),
                    overall.get("summary") or "")

    def team_id(c):
        return str((c.get("team") or {}).get("id") or c.get("id") or "")

    situation = competition.get("situation") or {}
    possession = ""
    holder = str(situation.get("possession") or "")
    if state == "live" and holder:
        possession = "home" if holder == team_id(home) else "away" if holder == team_id(away) else ""

    return {
        "id": f"espn-{event.get('id')}",
        "kickoff": parse_time(event.get("date")) or 0,
        "state": state,
        "minute": minute,
        "home": side(home),
        "away": side(away),
        "scoreHome": score(home),
        "scoreAway": score(away),
        "possession": possession,
        "down": str(situation.get("shortDownDistanceText") or situation.get("downDistanceText") or "")
        if state == "live" else "",
    }


# Die Play-off-Runden der NFL (season type 3, Woche 1-5).
NFL_PLAYOFFS = {1: "Wild Card", 2: "Divisional Round", 3: "Conference Championships", 4: "Pro Bowl",
                5: "Super Bowl"}


def round_name(league_id, data, events):
    """"Woche 7", "Vorbereitung Woche 2" oder der Name der Play-off-Runde,
    auf Deutsch; texts.round_name übersetzt."""
    week = (data or {}).get("week") or (events[0].get("week") if events else None) or {}
    season = (data or {}).get("season") or (events[0].get("season") if events else None) or {}
    number = as_int(week.get("number"))
    kind = as_int(season.get("type"))
    if not number:
        return ""
    if kind == 1:
        return f"Vorbereitung Woche {number}"
    if kind == 3:
        if league_id == "nfl" and number in NFL_PLAYOFFS:
            return NFL_PLAYOFFS[number]
        return "Play-offs"
    if kind == 4:
        return "Off-Season"
    return f"Woche {number}"


def espn_round(league_id):
    """Die aktuelle Woche: ohne Datum liefert ESPN bei Football genau die
    laufende oder die nächste Woche."""
    league = LEAGUES[league_id]
    url = f"{ESPN_SITE}/{league['espn']}/scoreboard"
    extra = {"groups": league["groups"]} if league.get("groups") else {}
    try:
        data = get_json(url, {"limit": 300, **extra})
    except SourceError:
        data = get_json(url, extra or None)  # falls das Limit abgelehnt wird
    events = [e for e in (data or {}).get("events") or [] if isinstance(e, dict)]
    matches = sorted((espn_match(e) for e in events), key=lambda m: m["kickoff"])
    return {"round": round_name(league_id, data, events), "matches": matches}


# --------------------------------------------------------------------------
# Tabelle
# --------------------------------------------------------------------------

def _leaf_groups(node, parent=""):
    """Die Gruppen mit Einträgen (Conferences oder Divisions)."""
    name = node.get("abbreviation") or node.get("shortName") or node.get("name") or parent
    entries = ((node.get("standings") or {}).get("entries")) or []
    if entries:
        yield name, entries
    for child in node.get("children") or []:
        if isinstance(child, dict):
            yield from _leaf_groups(child, name)


def _stat(stats, *names):
    for n in names:
        if n in stats and stats[n].get("value") is not None:
            try:
                return float(stats[n]["value"])
            except (TypeError, ValueError):
                pass
    return None


def _conference_groups(data, conf):
    """Nur die Gruppen einer Conference (bei College Football liefert ESPN
    sonst alle). Ohne Treffer alle Gruppen."""
    groups = list(_leaf_groups(data or {}))
    key = conf.lower().replace(" ", "")
    mine = [(g, e) for g, e in groups if key in str(g).lower().replace(" ", "")]
    return mine or groups


def espn_table(code, groups=None, conf=None):
    """Zeilen in der Form des Fußball-Pakets, mit Bilanz statt Spielen und
    Siegquote statt Punkten: {"rank", "team", "played": "5-2", "diff",
    "points": ".714", "group": "AFC"}."""
    url = f"{ESPN_STANDINGS}/{code}/standings"
    if groups:
        try:
            data = get_json(url, {"group": groups})
        except SourceError:
            data = get_json(url)
        found = _conference_groups(data, conf or "")
    else:
        found = list(_leaf_groups(get_json(url) or {}))
    rows = []
    for group, entries in found:
        block = []
        for entry in entries:
            stats = {s.get("name") or s.get("type"): s for s in entry.get("stats") or [] if isinstance(s, dict)}
            wins, losses, ties = (int(_stat(stats, n) or 0) for n in ("wins", "losses", "ties"))
            games = wins + losses + ties
            pct = _stat(stats, "winPercent", "winpercent")
            if pct is None:
                pct = (wins + ties / 2) / games if games else 0.0
            diff = _stat(stats, "pointDifferential", "differential")
            if diff is None:
                diff = (_stat(stats, "pointsFor") or 0) - (_stat(stats, "pointsAgainst") or 0)
            t = entry.get("team") or {}
            block.append({
                "seed": int(_stat(stats, "playoffSeed") or 0),
                "team": team(t.get("displayName"), t.get("shortDisplayName") or t.get("name"), espn_logo(t)),
                "played": f"{wins}-{losses}" + (f"-{ties}" if ties else ""),
                "diff": int(diff),
                "pct": pct,
                "points": "1.000" if pct >= 1 else f"{pct:.3f}"[1:],
                "group": group,
            })
        if all(r["seed"] for r in block):
            block.sort(key=lambda r: r["seed"])
        else:
            block.sort(key=lambda r: (-r["pct"], -r["diff"]))
        for index, row in enumerate(block, start=1):
            row["rank"] = index
            del row["seed"], row["pct"]
        rows.extend(block)
    if not rows:
        raise SourceError(f"ESPN {code}: keine Tabelle")
    return rows


# --------------------------------------------------------------------------
# Eine Liga lesen
# --------------------------------------------------------------------------

def fetch_matches(league_id, now=None):
    """(round, matches, source)."""
    result = espn_round(league_id)
    return result["round"], result["matches"], "ESPN"


def fetch_table(league_id, now=None):
    league = LEAGUES[league_id]
    return espn_table(league["espn"], league.get("groups"), league.get("conf"))


# --------------------------------------------------------------------------
# Teams einer Liga für die Auswahl „Mein Team“
# --------------------------------------------------------------------------

# College ohne Conference wären über 130 Teams; die stehen in ihren Conferences.
TEAM_LEAGUES = [lid for lid in LEAGUES if lid != "ncaaf"]

_HEX = re.compile(r"^#?([0-9a-fA-F]{6})$")


def hex_color(value):
    match = _HEX.match(str(value or "").strip())
    return f"#{match.group(1).lower()}" if match else ""


def espn_teams(code, groups=None):
    """[{id, name, short, logo, color, alt}] aus ESPN /teams, mit Teamfarben."""
    params = {"limit": 1000, **({"groups": groups} if groups else {})}
    data = get_json(f"{ESPN_SITE}/{code}/teams", params)
    raw = []
    for sport in (data or {}).get("sports") or []:
        for league in sport.get("leagues") or []:
            raw.extend(league.get("teams") or [])
    teams = []
    for item in raw:
        t = (item or {}).get("team") or item or {}
        if not isinstance(t, dict) or not t.get("displayName") or t.get("isActive") is False:
            continue
        teams.append({"id": str(t.get("id") or t.get("displayName"))[:20], "name": t["displayName"],
                      "short": t.get("shortDisplayName") or t.get("name") or t["displayName"],
                      "logo": espn_logo(t),
                      "color": hex_color(t.get("color")), "alt": hex_color(t.get("alternateColor"))})
    if not teams:
        raise SourceError(f"ESPN {code}: keine Teams")
    return sorted(teams, key=lambda x: x["name"].lower())


def fetch_teams(league_id):
    league = LEAGUES[league_id]
    return espn_teams(league["espn"], league.get("groups"))


def _luminance(color):
    channels = []
    for i in (1, 3, 5):
        c = int(color[i:i + 2], 16) / 255
        channels.append(c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4)
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]


def team_accent(color, alt):
    """Akzentfarbe aus den Teamfarben, die auf dunklem Grund zu sehen ist,
    und die Schriftfarbe darauf. ("", "") ohne Farben."""
    colors = [c for c in (hex_color(color), hex_color(alt)) if c]
    if not colors:
        return "", ""
    usable = [c for c in colors if 0.03 <= _luminance(c) <= 0.9]
    accent = usable[0] if usable else max(colors, key=_luminance)
    if _luminance(accent) < 0.03:
        accent = "#c8ccd4"  # schwarz und dunkelblau ginge auf dem dunklen Grund unter
    ink = "#0b0e14" if _luminance(accent) > 0.35 else "#ffffff"
    return accent, ink
