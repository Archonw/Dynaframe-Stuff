"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    'Die Szene Biathlon Live ist auf der Plugins-Seite ausgeschaltet.': (
        'The Biathlon Live scene is switched off on the Plugins page.',
        'La escena Biathlon Live está desactivada en la página de plugins.'),
    'Die Szene Biathlon Live ist auf diesem Rahmen nicht installiert. Installiere das Biathlon-Live-Paket noch einmal.': (
        'The Biathlon Live scene is not installed on this frame. Install the Biathlon Live package again.',
        'La escena Biathlon Live no está instalada en este marco. Vuelve a instalar el paquete Biathlon Live.'),
    'Der Rahmen hat die Playlist {name} nicht angelegt.': (
        'The frame did not create the playlist {name}.',
        'El marco no ha creado la lista {name}.'),
    'Wartet, bis der Bildschirm wieder frei ist.': (
        'Waiting until the screen is free again.',
        'Esperando a que la pantalla vuelva a estar libre.'),
    'Konnte die Takeover-Playlist nicht anlegen: {exc}': (
        'Could not create the takeover playlist: {exc}',
        'No se pudo crear la lista de takeover: {exc}'),
    'Konnte die Playlist Biathlon Live nicht pflegen: {exc}': (
        'Could not maintain the Biathlon Live playlist: {exc}',
        'No se pudo mantener la lista Biathlon Live: {exc}'),
    'Angelegt: die Playlist Biathlon Live steht unter Playlists.': (
        'Created: the Biathlon Live playlist is listed under Playlists.',
        'Creada: la lista Biathlon Live aparece en Playlists.'),
    'Noch nicht angelegt; das passiert innerhalb einer Minute.': (
        'Not created yet; this happens within a minute.',
        'Todavía no creada; se creará en menos de un minuto.'),
    'Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.': (
        'The playlist was deleted, so this is set back to No.',
        'La lista se ha borrado, por eso vuelve a estar en No.'),
    'Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.': (
        'The playlist created earlier is still under Playlists; the plugin no longer maintains it.',
        'La lista creada antes sigue en Playlists; el plugin ya no la mantiene.'),
    'Biathlon Live ist auf der Plugins-Seite ausgeschaltet.': (
        'Biathlon Live is switched off on the Plugins page.',
        'Biathlon Live está desactivado en la página de plugins.'),
    '„Allow takeover“ ist für Biathlon Live auf der Plugins-Seite aus, deshalb kann es den Bildschirm nicht übernehmen.': (
        '“Allow takeover” is off for Biathlon Live on the Plugins page, so it cannot take over the screen.',
        '«Allow takeover» está desactivado para Biathlon Live en la página de plugins, así que no puede ocupar la pantalla.'),
    'Der Rahmen hat die Anzeige beendet ({state}).': (
        'The frame ended the display ({state}).',
        'El marco ha terminado la visualización ({state}).'),
    'Biathlon Live ist schon auf dem Bildschirm.': (
        'Biathlon Live is already on screen.',
        'Biathlon Live ya está en pantalla.'),
    'Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.': (
        'This frame is too old to hand the screen to a plugin.',
        'Este marco es demasiado antiguo para ceder la pantalla a un plugin.'),
    'Die Szene Biathlon Live wurde nicht gefunden.': (
        'The Biathlon Live scene was not found.',
        'No se ha encontrado la escena Biathlon Live.'),
    'Die Takeover-Playlist ist noch nicht angelegt.': (
        'The takeover playlist has not been created yet.',
        'La lista de takeover aún no se ha creado.'),
    'Biathlon Live läuft gerade in deiner Playlist; die Anzeige bleibt so.': (
        'Biathlon Live is currently playing in your playlist; the display stays as it is.',
        'Biathlon Live se está mostrando en tu lista; la pantalla se queda así.'),
    'Der Bildschirm ist aus. Biathlon Live weckt ihn nicht.': (
        'The screen is off. Biathlon Live does not wake it.',
        'La pantalla está apagada. Biathlon Live no la enciende.'),
    'Konnte Biathlon Live nicht anzeigen: {exc}': (
        'Could not show Biathlon Live: {exc}',
        'No se pudo mostrar Biathlon Live: {exc}'),
    'Etwas anderes hat gerade den Bildschirm.': (
        'Something else has the screen right now.',
        'Otra cosa está usando la pantalla ahora mismo.'),
    'Der Rahmen hat Biathlon Live nicht rechtzeitig angezeigt.': (
        'The frame did not show Biathlon Live in time.',
        'El marco no mostró Biathlon Live a tiempo.'),
    'Biathlon Live hatte den Bildschirm nicht.': (
        'Biathlon Live did not have the screen.',
        'Biathlon Live no tenía la pantalla.'),
    'Bitte den Rahmen um den Bildschirm.': (
        'Asking the frame for the screen.',
        'Pidiendo la pantalla al marco.'),
    'Gebe den Bildschirm zurück.': (
        'Handing the screen back.',
        'Devolviendo la pantalla.'),
    '{name} hat nicht geklappt: {exc}': (
        '{name} did not work: {exc}',
        '{name} no ha funcionado: {exc}'),
    'Der Rahmen ist nach Biathlon Live nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.': (
        "The frame did not return to your playlist after Biathlon Live. Restart it on the frame's home page. This does not happen with a saved playlist instead of a Quick Mix.",
        'El marco no volvió a tu lista después de Biathlon Live. Vuelve a iniciarla en la página principal del marco. Con una lista guardada en lugar de un Quick Mix esto no pasa.'),
    'Regelmäßige Anzeige ist aus.': (
        'Regular display is off.',
        'La visualización periódica está desactivada.'),
    'Außerhalb von {start}–{end} Uhr.': (
        'Outside {start}:00–{end}:00.',
        'Fuera del horario {start}:00–{end}:00.'),
    'Live: {scores}': (
        'Live: {scores}',
        'En vivo: {scores}'),
    'Lese die Ergebnisse jetzt neu.': (
        'Reading the results again now.',
        'Leyendo los resultados de nuevo.'),
    'Keine Serie gewählt.': (
        'No series selected.',
        'No hay ninguna serie elegida.'),
    'Gerade läuft kein Rennen.': (
        'No race is running right now.',
        'Ahora mismo no hay ninguna carrera en curso.'),
    'Heute ist in den gewählten Serien kein Renntag.': (
        'There is no race today in the selected series.',
        'Hoy no hay carreras en las series elegidas.'),
    'Live: {race}{lead}': (
        'Live: {race}{lead}',
        'En vivo: {race}{lead}'),
    'Nächstes Rennen: {when} {race} ({place})': (
        'Next race: {when} {race} ({place})',
        'Próxima carrera: {when} {race} ({place})'),
    'Keine Rennen angesetzt': (
        'No races scheduled',
        'No hay carreras previstas'),
}


def language(value):
    value = str(value or "").strip().lower()
    return value if value in LANGUAGES else "de"


def t(lang, template, **values):
    lang = language(lang)
    text = template
    if lang != "de":
        pair = _TEXTS.get(template)
        if pair:
            text = pair[LANGUAGES.index(lang) - 1]
    return text.format(**values) if values else text
