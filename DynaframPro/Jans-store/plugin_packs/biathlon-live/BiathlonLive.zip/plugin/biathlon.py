"""Die Datenquelle von Biathlon Live: die öffentliche Schnittstelle von
biathlonresults.com (IBU Datacenter), dieselbe wie im MagicMirror-Modul
MMM-Biathlon von 2hdlockness (MIT).

  Events?SeasonId=2627&Level=ALL   Weltcup-Stationen, WM, IBU-Cup ... einer Saison
  Competitions?EventId=...         die Rennen einer Station
  Results?RaceId=...               Ergebnis (im Rennen: der Zwischenstand)
  Cups?SeasonId=... / CupResults?CupId=...   Gesamtwertungen

Kein Konto, kein Schlüssel. Die Antworten werden hier in eine kleine, feste
Form gebracht, damit Plugin und Szene nicht an den Feldnamen der IBU hängen.
"""

import os
import re
import time
from datetime import datetime, timezone

import requests

API = os.environ.get("BIATHLON_API_URL", "https://biathlonresults.com/modules/sportapi/api/").rstrip("/") + "/"
HTTP_HEADERS = {"User-Agent": "DynaFrame-BiathlonLive/1.0 (+https://github.com/Archonw/Dynaframe-Stuff)",
                "Accept": "application/json"}
TIMEOUT = (10, 30)


class SourceError(Exception):
    pass


def get(method, **params):
    try:
        response = requests.get(API + method, params=params, headers=HTTP_HEADERS, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError(f"biathlonresults.com nicht erreichbar: {exc}") from exc
    if response.status_code >= 400:
        raise SourceError(f"biathlonresults.com lieferte HTTP {response.status_code} ({method})")
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError(f"biathlonresults.com lieferte kein JSON ({method})") from exc


# --------------------------------------------------------------------------
# Serien (EventClassificationId, wie in MMM-Biathlon)
# --------------------------------------------------------------------------

# id -> Namen (de, en, es), Farbe, ob es eine Gesamtwertung gibt
SERIES = {
    "BTSWRLCP": {"names": ("BMW IBU Weltcup", "BMW IBU World Cup", "Copa del Mundo BMW IBU"), "color": "#1f6feb", "cup": True},
    "BTSWRLCH": {"names": ("Biathlon-WM", "World Championships", "Campeonato del Mundo"), "color": "#c8102e", "cup": False},
    "BTSIBUCP": {"names": ("IBU-Cup", "IBU Cup", "Copa IBU"), "color": "#0f9d8a", "cup": True},
    "BTSCEUCH": {"names": ("Europameisterschaften", "European Championships", "Campeonato de Europa"), "color": "#7c4dff", "cup": False},
    "BTJIBUCP": {"names": ("IBU Junior Cup", "IBU Junior Cup", "Copa IBU júnior"), "color": "#e08a00", "cup": True},
    "BTJWRLCH": {"names": ("Jugend-/Junioren-WM", "Youth/Junior World Championships", "Mundial júnior y juvenil"), "color": "#d6336c", "cup": False},
    "BTJCEUCH": {"names": ("Junioren-EM", "Junior European Championships", "Europeo júnior"), "color": "#9c36b5", "cup": False},
    "SBSWRLCH": {"names": ("Sommerbiathlon-WM", "Summer Biathlon World Championships", "Mundial de biatlón de verano"), "color": "#f59f00", "cup": False},
    "BTSWRLUG": {"names": ("Universiade", "World University Games", "Universiada"), "color": "#1c7ed6", "cup": False},
    "BTJCEUOF": {"names": ("EYOF", "European Youth Olympic Festival", "Festival Olímpico de la Juventud Europea"), "color": "#2f9e44", "cup": False},
}
DEFAULT_SERIES = ["BTSWRLCP", "BTSWRLCH"]
LANGS = ("de", "en", "es")


def series_name(series_id, lang):
    row = SERIES.get(series_id)
    if not row:
        return series_id
    return row["names"][LANGS.index(lang) if lang in LANGS else 0]


def season_id(moment=None):
    """Die Saison läuft von Herbst bis Frühjahr: im Oktober 2026 ist es 2627."""
    moment = moment or datetime.now()
    start = moment.year if moment.month >= 7 else moment.year - 1
    return f"{start % 100:02d}{(start + 1) % 100:02d}"


def previous_season(season):
    start = int(season[:2])
    return f"{(start - 1) % 100:02d}{start:02d}"


def parse_time(text):
    """ISO-Zeit der IBU ("2026-11-29T11:15:00Z", Daten auch ohne Zone) als epoch."""
    text = str(text or "").strip()
    if not text:
        return 0
    try:
        moment = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return 0
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.timestamp()


# --------------------------------------------------------------------------
# Stationen und Rennen
# --------------------------------------------------------------------------

def fetch_events(season):
    rows = get("Events", SeasonId=season, Level="ALL")
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf Events")
    events = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("EventId"):
            continue
        events.append({
            "id": str(row["EventId"]),
            "series": str(row.get("EventClassificationId") or ""),
            "place": str(row.get("ShortDescription") or row.get("Organizer") or ""),
            "description": str(row.get("Description") or ""),
            "nat": str(row.get("Nat") or "")[:3].upper(),
            "start": parse_time(row.get("StartDate")),
            # Enddatum ohne Uhrzeit: der ganze Tag gehört noch dazu.
            "end": parse_time(row.get("EndDate")) + 86399,
        })
    events.sort(key=lambda e: e["start"])
    return events


# Kategorie und Disziplin stehen in den letzten vier Zeichen der RaceId:
# BT2425SWRLCP01SWSI = Frauen (SW), verkürztes Einzel (SI).
CATEGORIES = {
    "SW": ("Frauen", "Women", "Femenino"), "SM": ("Männer", "Men", "Masculino"),
    "MX": ("Mixed", "Mixed", "Mixto"),
    "JW": ("Juniorinnen", "Junior women", "Júnior femenino"), "JM": ("Junioren", "Junior men", "Júnior masculino"),
    "JX": ("Junioren Mixed", "Junior mixed", "Júnior mixto"),
    "YW": ("Jugend weiblich", "Youth women", "Juvenil femenino"), "YM": ("Jugend männlich", "Youth men", "Juvenil masculino"),
    "YX": ("Jugend Mixed", "Youth mixed", "Juvenil mixto"),
}
DISCIPLINES = {
    "SP": ("Sprint", "Sprint", "Sprint"),
    "PU": ("Verfolgung", "Pursuit", "Persecución"),
    "IN": ("Einzel", "Individual", "Individual"),
    "SI": ("Verkürztes Einzel", "Short Individual", "Individual corto"),
    "MS": ("Massenstart", "Mass Start", "Salida en masa"),
    "RL": ("Staffel", "Relay", "Relevos"),
    "SR": ("Single-Mixed-Staffel", "Single Mixed Relay", "Relevo mixto simple"),
    "SS": ("Super Sprint", "Super Sprint", "Super sprint"),
    "SF": ("Super Sprint Finale", "Super Sprint Final", "Final de super sprint"),
    "SQ": ("Super Sprint Quali", "Super Sprint Qualification", "Clasificación super sprint"),
}
RELAYS = {"RL", "SR"}


def race_codes(race_id):
    tail = str(race_id or "")[-4:].upper()
    return tail[:2], tail[2:]


def race_name(race, lang):
    """"Sprint 7,5 km · Frauen" aus den Codes, sonst der Name der IBU."""
    cat, disc = race.get("category"), race.get("discipline")
    i = LANGS.index(lang) if lang in LANGS else 0
    if disc not in DISCIPLINES or cat not in CATEGORIES:
        return race.get("raw") or race.get("id") or ""
    name = DISCIPLINES[disc][i]
    if disc == "RL" and cat == "MX":
        name = ("Mixed-Staffel", "Mixed Relay", "Relevo mixto")[i]
    km = race.get("km") or ""
    if km and lang in ("de", "es"):
        km = km.replace(".", ",")
    parts = [f"{name} {km}".strip()]
    if not (disc == "SR" or (disc == "RL" and cat == "MX")):
        parts.append(CATEGORIES[cat][i])
    elif cat != "MX":
        parts.append(CATEGORIES[cat][i])
    return " · ".join(parts)


DISTANCE = re.compile(r"(\d+\s*x\s*)?(\d+(?:[.,]\d+)?)\s*km", re.I)


def fetch_competitions(event_id):
    rows = get("Competitions", EventId=event_id)
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf Competitions")
    races = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("RaceId"):
            continue
        raw = str(row.get("ShortDescription") or row.get("Description") or "")
        cat, disc = race_codes(row["RaceId"])
        distance = DISTANCE.search(raw)
        km = ""
        if distance:
            km = (distance.group(1) or "").replace(" ", "").replace("x", "×") + distance.group(2) + " km"
        races.append({
            "id": str(row["RaceId"]), "event": event_id, "start": parse_time(row.get("StartTime")),
            "raw": raw, "category": cat, "discipline": disc, "km": km,
            "relay": disc in RELAYS,
            "status": str(row.get("StatusText") or ""),
            "isLive": bool(row.get("IsLive")),
        })
    races.sort(key=lambda r: r["start"])
    return races


# --------------------------------------------------------------------------
# Ergebnisse
# --------------------------------------------------------------------------

IRM = {"DNF", "DNS", "DSQ", "LAP", "DNE", "OTL"}


def as_rank(value):
    try:
        return int(str(value).strip().rstrip("."))
    except (TypeError, ValueError):
        return None


def person_name(name):
    """"BOE Johannes Thingnes" -> ("Johannes Thingnes Boe", "J. Boe")."""
    text = str(name or "").strip()
    words = text.split()
    family = []
    for word in words:
        letters = re.sub(r"[^\w]", "", word)
        if letters and letters.isupper():
            family.append(word)
        else:
            break
    if not family:
        return text, text
    nice = " ".join("-".join(p[:1].upper() + p[1:].lower() for p in w.split("-")) for w in family)
    given = words[len(family):]
    if not given:
        return nice, nice
    return f"{' '.join(given)} {nice}", f"{given[0][:1]}. {nice}"


def shootings(text):
    """"0+1+0+0" -> [0, 1, 0, 0]. Staffeln ("0+2 1+3": Strafrunden+Nachlader)
    bekommen keine Liste; dort zeigt die Szene den Text."""
    text = str(text or "").strip()
    if not re.fullmatch(r"\d+(\+\d+){1,7}", text):
        return []
    return [int(x) for x in text.split("+")]


def fetch_results(race_id, relay=False):
    data = get("Results", RaceId=race_id)
    if not isinstance(data, dict):
        raise SourceError("Unerwartete Antwort auf Results")
    rows = [r for r in data.get("Results") or [] if isinstance(r, dict)]
    if relay:
        teams = [r for r in rows if r.get("IsTeam") is True]
        if teams:
            rows = teams
        else:
            # Ohne IsTeam: je Platz nur die erste Zeile (wie MMM-Biathlon)
            seen, teams = set(), []
            for r in rows:
                key = r.get("Rank") or r.get("ResultOrder")
                if key not in seen:
                    seen.add(key)
                    teams.append(r)
            rows = teams
    out = []
    for r in rows:
        irm = str(r.get("IRM") or "").strip().upper()
        rank = as_rank(r.get("Rank"))
        full, short = person_name(r.get("Name") or r.get("ShortName"))
        out.append({
            "rank": rank, "irm": irm[:4],
            "name": full, "short": short, "nat": str(r.get("Nat") or "")[:3].upper(),
            "bib": str(r.get("Bib") or ""),
            "time": str(r.get("TotalTime") or r.get("Result") or ""),
            "behind": str(r.get("Behind") or ""),
            "shootings": shootings(r.get("Shootings")),
            "shootingText": str(r.get("Shootings") or "")[:40],
            "shootingTotal": as_rank(r.get("ShootingTotal")),
            "team": bool(relay),
        })
    competition = data.get("Competition") if isinstance(data.get("Competition"), dict) else {}
    ranked = [x for x in out if x["rank"] is not None]
    ranked.sort(key=lambda x: x["rank"])
    others = [x for x in out if x["rank"] is None]
    return {
        "rows": ranked + others,
        "ranked": len(ranked),
        "open": sum(1 for x in others if not x["irm"]),
        "isStartList": bool(data.get("IsStartList")),
        "status": str(competition.get("StatusText") or ""),
        "isLive": bool(competition.get("IsLive")),
    }


FINAL_WORDS = ("official", "final", "unofficial", "result")
LIVE_WORDS = ("started", "running", "live", "in progress")


def race_state(race, result, t=None):
    """pre, live, post oder off (abgesagt)."""
    t = t or time.time()
    status = " ".join(filter(None, [race.get("status"), (result or {}).get("status")])).lower()
    if any(w in status for w in ("cancel", "postpon", "abgesagt")):
        return "off"
    if not race.get("start") or t < race["start"]:
        return "pre"
    if any(w in status for w in FINAL_WORDS) and "start list" not in status:
        return "post"
    if race.get("isLive") or (result or {}).get("isLive") or any(w in status for w in LIVE_WORDS):
        return "live" if t - race["start"] < 4 * 3600 else "post"
    if result is not None and result["ranked"] and not result["open"]:
        return "post"
    # Gestartet, aber noch nicht alle im Ziel: bis zu drei Stunden lang live.
    return "live" if t - race["start"] < 3 * 3600 else "post"


# --------------------------------------------------------------------------
# Gesamtwertungen
# --------------------------------------------------------------------------

def find_cups(season, series):
    """{"SW": CupId, "SM": CupId} der Gesamtwertung einer Serie."""
    rows = get("Cups", SeasonId=season)
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf Cups")
    key = series[2:]  # BTSWRLCP -> SWRLCP
    found = {}
    for row in rows:
        cup_id = str((row or {}).get("CupId") or "")
        match = re.match(rf"^BT{season}{key}__(S|J)([WM])TS$", cup_id)
        if match:
            found[match.group(1) + match.group(2)] = cup_id
    return {("SW" if k.endswith("W") else "SM"): v for k, v in found.items()}


def fetch_cup(cup_id):
    data = get("CupResults", CupId=cup_id)
    rows = (data or {}).get("Rows") if isinstance(data, dict) else None
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf CupResults")
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        full, short = person_name(r.get("Name"))
        out.append({"rank": as_rank(r.get("Rank")), "name": full, "short": short,
                    "nat": str(r.get("Nat") or "")[:3].upper(),
                    "score": str(r.get("Score") or r.get("Points") or "")})
    return [r for r in out if r["rank"] is not None]
