"""Nationen im Biathlon: IOC-Code -> Name auf Deutsch, Englisch, Spanisch.

Staffeln heißen bei der IBU wie ihre Nation ("NORWAY"); die Szene zeigt
stattdessen diesen Namen in der eingestellten Sprache. Die Flaggen liegen
als dynamic/flags/<code>.svg in der Szene.
"""

NATIONS = {
    "GER": ("Deutschland", "Germany", "Alemania"),
    "AUT": ("Österreich", "Austria", "Austria"),
    "SUI": ("Schweiz", "Switzerland", "Suiza"),
    "FRA": ("Frankreich", "France", "Francia"),
    "NOR": ("Norwegen", "Norway", "Noruega"),
    "SWE": ("Schweden", "Sweden", "Suecia"),
    "FIN": ("Finnland", "Finland", "Finlandia"),
    "ITA": ("Italien", "Italy", "Italia"),
    "CZE": ("Tschechien", "Czechia", "Chequia"),
    "SVK": ("Slowakei", "Slovakia", "Eslovaquia"),
    "SLO": ("Slowenien", "Slovenia", "Eslovenia"),
    "POL": ("Polen", "Poland", "Polonia"),
    "UKR": ("Ukraine", "Ukraine", "Ucrania"),
    "BLR": ("Belarus", "Belarus", "Bielorrusia"),
    "RUS": ("Russland", "Russia", "Rusia"),
    "EST": ("Estland", "Estonia", "Estonia"),
    "LAT": ("Lettland", "Latvia", "Letonia"),
    "LTU": ("Litauen", "Lithuania", "Lituania"),
    "BEL": ("Belgien", "Belgium", "Bélgica"),
    "NED": ("Niederlande", "Netherlands", "Países Bajos"),
    "GBR": ("Großbritannien", "Great Britain", "Gran Bretaña"),
    "IRL": ("Irland", "Ireland", "Irlanda"),
    "ESP": ("Spanien", "Spain", "España"),
    "AND": ("Andorra", "Andorra", "Andorra"),
    "BUL": ("Bulgarien", "Bulgaria", "Bulgaria"),
    "ROU": ("Rumänien", "Romania", "Rumanía"),
    "MDA": ("Moldau", "Moldova", "Moldavia"),
    "CRO": ("Kroatien", "Croatia", "Croacia"),
    "SRB": ("Serbien", "Serbia", "Serbia"),
    "BIH": ("Bosnien und Herzegowina", "Bosnia and Herzegovina", "Bosnia y Herzegovina"),
    "GRE": ("Griechenland", "Greece", "Grecia"),
    "HUN": ("Ungarn", "Hungary", "Hungría"),
    "DEN": ("Dänemark", "Denmark", "Dinamarca"),
    "ISL": ("Island", "Iceland", "Islandia"),
    "TUR": ("Türkei", "Türkiye", "Turquía"),
    "KAZ": ("Kasachstan", "Kazakhstan", "Kazajistán"),
    "MGL": ("Mongolei", "Mongolia", "Mongolia"),
    "CHN": ("China", "China", "China"),
    "JPN": ("Japan", "Japan", "Japón"),
    "KOR": ("Südkorea", "South Korea", "Corea del Sur"),
    "CAN": ("Kanada", "Canada", "Canadá"),
    "USA": ("USA", "United States", "Estados Unidos"),
    "AUS": ("Australien", "Australia", "Australia"),
    "ARG": ("Argentinien", "Argentina", "Argentina"),
    "BRA": ("Brasilien", "Brazil", "Brasil"),
    "CHI": ("Chile", "Chile", "Chile"),
}
LANGS = ("de", "en", "es")


def name(code, lang, fallback=""):
    row = NATIONS.get(str(code or "").upper())
    if not row:
        return fallback or str(code or "")
    return row[LANGS.index(lang) if lang in LANGS else 0]


def choices(lang):
    return sorted(({"id": k, "name": name(k, lang)} for k in NATIONS), key=lambda x: x["name"])
